package com.cricketmanager.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = PitchEmerald,
    onPrimary = Color.White,
    primaryContainer = PitchEmeraldSoft,
    onPrimaryContainer = PitchEmeraldDark,
    secondary = GoldAccent,
    onSecondary = Color.White,
    secondaryContainer = GoldAccentSoft,
    error = BoundaryCrimson,
    errorContainer = BoundaryCrimsonSoft,
    background = StadiumOffWhite,
    onBackground = NavyInk,
    surface = CardWhite,
    onSurface = NavyInk,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = SlateInk,
    outline = DividerGrey
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF10B981),
    onPrimary = Color(0xFF022C22),
    primaryContainer = PitchEmeraldDark,
    onPrimaryContainer = PitchEmeraldSoft,
    secondary = Color(0xFFF59E0B),
    error = Color(0xFFF87171),
    background = DarkStadiumBg,
    onBackground = Color(0xFFF8FAFC),
    surface = DarkCardBg,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF334155)
)

@Composable
fun CricketManagerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = CricketTypography,
        content = content
    )
}
