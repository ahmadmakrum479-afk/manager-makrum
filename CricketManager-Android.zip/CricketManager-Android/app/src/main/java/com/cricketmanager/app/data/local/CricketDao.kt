package com.cricketmanager.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.cricketmanager.app.domain.CricketStatsEngine
import kotlinx.coroutines.flow.Flow

@Dao
interface CricketDao {

    @Query("SELECT * FROM users ORDER BY id ASC")
    fun observeAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: Long): UserEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity): Long

    @Query("SELECT * FROM tournaments ORDER BY updatedAt DESC")
    fun observeAllTournaments(): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments ORDER BY updatedAt DESC")
    suspend fun getAllTournamentsOnce(): List<TournamentEntity>

    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
    suspend fun getTournamentById(id: Long): TournamentEntity?

    @Query(
        "SELECT * FROM tournaments WHERE UPPER(tournamentCode) = UPPER(:code) OR UPPER(editorCode) = UPPER(:code) OR UPPER(viewerCode) = UPPER(:code) LIMIT 1"
    )
    suspend fun findTournamentByAnyCode(code: String): TournamentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: TournamentEntity): Long

    @Update
    suspend fun updateTournament(tournament: TournamentEntity)

    @Query("DELETE FROM tournaments WHERE id = :tournamentId")
    suspend fun deleteTournament(tournamentId: Long)

    @Query("SELECT * FROM teams ORDER BY points DESC, (runsFor - runsAgainst) DESC, name ASC")
    fun observeAllTeams(): Flow<List<TeamEntity>>

    @Query("SELECT * FROM teams WHERE tournamentId = :tournamentId")
    suspend fun getTeamsByTournamentOnce(tournamentId: Long): List<TeamEntity>

    @Query("SELECT * FROM teams WHERE id = :teamId LIMIT 1")
    suspend fun getTeamById(teamId: Long): TeamEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeam(team: TeamEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeams(teams: List<TeamEntity>): List<Long>

    @Update
    suspend fun updateTeam(team: TeamEntity)

    @Query("DELETE FROM teams WHERE id = :teamId")
    suspend fun deleteTeam(teamId: Long)

    @Query("SELECT * FROM players ORDER BY runsScored DESC, wicketsTaken DESC, name ASC")
    fun observeAllPlayers(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE tournamentId = :tournamentId")
    suspend fun getPlayersByTournamentOnce(tournamentId: Long): List<PlayerEntity>

    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY jerseyNumber ASC")
    suspend fun getPlayersByTeamOnce(teamId: Long): List<PlayerEntity>

    @Query("SELECT * FROM players WHERE id = :playerId LIMIT 1")
    suspend fun getPlayerById(playerId: Long): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayers(players: List<PlayerEntity>)

    @Update
    suspend fun updatePlayer(player: PlayerEntity)

    @Query("DELETE FROM players WHERE id = :playerId")
    suspend fun deletePlayer(playerId: Long)

    @Query("SELECT * FROM matches ORDER BY tournamentId ASC, matchNumber ASC, id ASC")
    fun observeAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE tournamentId = :tournamentId ORDER BY matchNumber ASC, id ASC")
    suspend fun getMatchesByTournamentOnce(tournamentId: Long): List<MatchEntity>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    suspend fun getMatchById(matchId: Long): MatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatches(matches: List<MatchEntity>)

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("DELETE FROM matches WHERE id = :matchId")
    suspend fun deleteMatch(matchId: Long)

    @Query("SELECT * FROM ball_events ORDER BY matchId ASC, innings ASC, sequenceNumber ASC, id ASC")
    fun observeAllBallEvents(): Flow<List<BallEventEntity>>

    @Query("SELECT * FROM ball_events WHERE matchId = :matchId ORDER BY innings ASC, sequenceNumber ASC, id ASC")
    suspend fun getBallEventsForMatchOnce(matchId: Long): List<BallEventEntity>

    @Query("SELECT * FROM ball_events WHERE matchId = :matchId AND innings = :innings ORDER BY sequenceNumber DESC, id DESC LIMIT 1")
    suspend fun getLastBallInInnings(matchId: Long, innings: Int): BallEventEntity?

    @Query("SELECT * FROM ball_events WHERE id = :ballId LIMIT 1")
    suspend fun getBallById(ballId: Long): BallEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBallEvent(ball: BallEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBallEvents(balls: List<BallEventEntity>)

    @Update
    suspend fun updateBallEvent(ball: BallEventEntity)

    @Query("DELETE FROM ball_events WHERE id = :ballId")
    suspend fun deleteBallEvent(ballId: Long)

    @Query("SELECT * FROM tournament_members ORDER BY joinedAt ASC")
    fun observeAllMembers(): Flow<List<TournamentMemberEntity>>

    @Query("SELECT * FROM tournament_members WHERE tournamentId = :tournamentId")
    suspend fun getMembersByTournamentOnce(tournamentId: Long): List<TournamentMemberEntity>

    @Query("SELECT * FROM tournament_members WHERE tournamentId = :tournamentId AND userId = :userId LIMIT 1")
    suspend fun getMember(tournamentId: Long, userId: Long): TournamentMemberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: TournamentMemberEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<TournamentMemberEntity>)

    @Update
    suspend fun updateMember(member: TournamentMemberEntity)

    @Query("DELETE FROM tournament_members WHERE id = :memberId")
    suspend fun deleteMember(memberId: Long)

    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 200")
    fun observeAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE tournamentId = :tournamentId ORDER BY createdAt DESC")
    suspend fun getAuditLogsOnce(tournamentId: Long): List<AuditLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLogs(logs: List<AuditLogEntity>)

    @Query("SELECT * FROM player_match_stats ORDER BY matchId ASC, innings ASC, id ASC")
    fun observeAllPlayerMatchStats(): Flow<List<PlayerMatchStatEntity>>

    @Query("SELECT * FROM player_match_stats WHERE matchId = :matchId ORDER BY innings ASC, id ASC")
    suspend fun getPlayerMatchStatsOnce(matchId: Long): List<PlayerMatchStatEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayerMatchStats(stats: List<PlayerMatchStatEntity>)

    @Query("DELETE FROM player_match_stats WHERE matchId = :matchId")
    suspend fun deletePlayerMatchStatsForMatch(matchId: Long)

    @Query("SELECT COUNT(*) FROM tournaments")
    suspend fun countTournaments(): Int

    @Transaction
    suspend fun recordBallAndApplyStats(
        matchId: Long,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean,
        wicketType: WicketType,
        dismissedPlayerId: Long,
        manualStrikeSwap: Boolean = false
    ) {
        val match = getMatchById(matchId) ?: return
        val isLegalBall = CricketStatsEngine.isLegalDelivery(extraType)
        val totalRunsForBall = runsOffBat + extraRuns

        val currentInnings = match.currentInnings
        val prevBalls = if (currentInnings == 1) match.teamABalls else match.teamBBalls
        val nextLegalBalls = prevBalls + if (isLegalBall) 1 else 0
        val overNum = if (isLegalBall) prevBalls / 6 else (prevBalls / 6)
        val ballInOver = if (isLegalBall) (prevBalls % 6) + 1 else (prevBalls % 6)

        val existingEvents = getBallEventsForMatchOnce(matchId).filter { it.innings == currentInnings }
        val nextSeq = (existingEvents.maxOfOrNull { it.sequenceNumber } ?: 0) + 1

        val label = CricketStatsEngine.formatBallChip(
            runsOffBat = runsOffBat,
            extraRuns = extraRuns,
            extraType = extraType,
            isWicket = isWicket
        )

        insertBallEvent(
            BallEventEntity(
                tournamentId = match.tournamentId,
                matchId = matchId,
                innings = currentInnings,
                sequenceNumber = nextSeq,
                overNumber = overNum,
                ballInOver = ballInOver,
                strikerId = strikerId,
                nonStrikerId = nonStrikerId,
                bowlerId = bowlerId,
                runsOffBat = runsOffBat,
                extraRuns = extraRuns,
                extraType = extraType,
                isWicket = isWicket,
                wicketType = wicketType,
                dismissedPlayerId = if (isWicket) dismissedPlayerId else 0L,
                isBoundaryFour = runsOffBat == 4,
                isBoundarySix = runsOffBat == 6,
                summaryLabel = label
            )
        )

        // Update Striker Batting Career Stats
        if (strikerId > 0L) {
            getPlayerById(strikerId)?.let { batter ->
                val batterBalls = if (extraType != ExtraType.WIDE) 1 else 0
                updatePlayer(
                    batter.copy(
                        runsScored = batter.runsScored + runsOffBat,
                        ballsFaced = batter.ballsFaced + batterBalls,
                        fours = batter.fours + if (runsOffBat == 4) 1 else 0,
                        sixes = batter.sixes + if (runsOffBat == 6) 1 else 0
                    )
                )
            }
        }

        // Update Bowler Bowling Career Stats
        if (bowlerId > 0L) {
            getPlayerById(bowlerId)?.let { bowler ->
                val bowlerConceded = when (extraType) {
                    ExtraType.BYE, ExtraType.LEG_BYE -> 0
                    else -> runsOffBat + extraRuns
                }
                val countsAsWicket = isWicket && wicketType != WicketType.RUN_OUT
                updatePlayer(
                    bowler.copy(
                        ballsBowled = bowler.ballsBowled + if (isLegalBall) 1 else 0,
                        runsConceded = bowler.runsConceded + bowlerConceded,
                        wicketsTaken = bowler.wicketsTaken + if (countsAsWicket) 1 else 0
                    )
                )
            }
        }

        // Strike rotation check
        var nextStriker = strikerId
        var nextNonStriker = nonStrikerId
        val oddRuns = (runsOffBat + if (extraType == ExtraType.BYE || extraType == ExtraType.LEG_BYE) extraRuns else 0) % 2 == 1
        if (oddRuns) {
            val tmp = nextStriker
            nextStriker = nextNonStriker
            nextNonStriker = tmp
        }
        val overJustCompleted = isLegalBall && nextLegalBalls > 0 && nextLegalBalls % 6 == 0
        if (overJustCompleted || manualStrikeSwap) {
            val tmp = nextStriker
            nextStriker = nextNonStriker
            nextNonStriker = tmp
        }
        if (isWicket && dismissedPlayerId > 0L) {
            if (nextStriker == dismissedPlayerId) nextStriker = 0L
            if (nextNonStriker == dismissedPlayerId) nextNonStriker = 0L
        }

        val updatedMatch = if (currentInnings == 1) {
            match.copy(
                status = MatchStatus.LIVE,
                teamARuns = match.teamARuns + totalRunsForBall,
                teamAWickets = match.teamAWickets + if (isWicket) 1 else 0,
                teamABalls = nextLegalBalls,
                teamAExtras = match.teamAExtras + extraRuns,
                activeStrikerId = nextStriker,
                activeNonStrikerId = nextNonStriker,
                activeBowlerId = bowlerId,
                resultSummary = "1st Innings Live",
                updatedAt = System.currentTimeMillis()
            )
        } else {
            val newRuns = match.teamBRuns + totalRunsForBall
            val target = match.teamARuns + 1
            val need = (target - newRuns).coerceAtLeast(0)
            match.copy(
                status = MatchStatus.LIVE,
                teamBRuns = newRuns,
                teamBWickets = match.teamBWickets + if (isWicket) 1 else 0,
                teamBBalls = nextLegalBalls,
                teamBExtras = match.teamBExtras + extraRuns,
                activeStrikerId = nextStriker,
                activeNonStrikerId = nextNonStriker,
                activeBowlerId = bowlerId,
                resultSummary = if (need == 0) "Target reached!" else "Need $need runs to win",
                updatedAt = System.currentTimeMillis()
            )
        }
        updateMatch(updatedMatch)
    }

    @Transaction
    suspend fun undoLastBallInMatch(matchId: Long) {
        val match = getMatchById(matchId) ?: return
        val lastBall = getLastBallInInnings(matchId, match.currentInnings) ?: return
        val isLegalBall = CricketStatsEngine.isLegalDelivery(lastBall.extraType)
        val totalRunsForBall = lastBall.runsOffBat + lastBall.extraRuns

        if (lastBall.strikerId > 0L) {
            getPlayerById(lastBall.strikerId)?.let { batter ->
                val batterBalls = if (lastBall.extraType != ExtraType.WIDE) 1 else 0
                updatePlayer(
                    batter.copy(
                        runsScored = (batter.runsScored - lastBall.runsOffBat).coerceAtLeast(0),
                        ballsFaced = (batter.ballsFaced - batterBalls).coerceAtLeast(0),
                        fours = (batter.fours - if (lastBall.runsOffBat == 4) 1 else 0).coerceAtLeast(0),
                        sixes = (batter.sixes - if (lastBall.runsOffBat == 6) 1 else 0).coerceAtLeast(0)
                    )
                )
            }
        }

        if (lastBall.bowlerId > 0L) {
            getPlayerById(lastBall.bowlerId)?.let { bowler ->
                val bowlerConceded = when (lastBall.extraType) {
                    ExtraType.BYE, ExtraType.LEG_BYE -> 0
                    else -> lastBall.runsOffBat + lastBall.extraRuns
                }
                val countsAsWicket = lastBall.isWicket && lastBall.wicketType != WicketType.RUN_OUT
                updatePlayer(
                    bowler.copy(
                        ballsBowled = (bowler.ballsBowled - if (isLegalBall) 1 else 0).coerceAtLeast(0),
                        runsConceded = (bowler.runsConceded - bowlerConceded).coerceAtLeast(0),
                        wicketsTaken = (bowler.wicketsTaken - if (countsAsWicket) 1 else 0).coerceAtLeast(0)
                    )
                )
            }
        }

        deleteBallEvent(lastBall.id)

        val revertedMatch = if (lastBall.innings == 1) {
            match.copy(
                teamARuns = (match.teamARuns - totalRunsForBall).coerceAtLeast(0),
                teamAWickets = (match.teamAWickets - if (lastBall.isWicket) 1 else 0).coerceAtLeast(0),
                teamABalls = (match.teamABalls - if (isLegalBall) 1 else 0).coerceAtLeast(0),
                teamAExtras = (match.teamAExtras - lastBall.extraRuns).coerceAtLeast(0),
                activeStrikerId = lastBall.strikerId,
                activeNonStrikerId = lastBall.nonStrikerId,
                activeBowlerId = lastBall.bowlerId,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            match.copy(
                teamBRuns = (match.teamBRuns - totalRunsForBall).coerceAtLeast(0),
                teamBWickets = (match.teamBWickets - if (lastBall.isWicket) 1 else 0).coerceAtLeast(0),
                teamBBalls = (match.teamBBalls - if (isLegalBall) 1 else 0).coerceAtLeast(0),
                teamBExtras = (match.teamBExtras - lastBall.extraRuns).coerceAtLeast(0),
                activeStrikerId = lastBall.strikerId,
                activeNonStrikerId = lastBall.nonStrikerId,
                activeBowlerId = lastBall.bowlerId,
                updatedAt = System.currentTimeMillis()
            )
        }
        updateMatch(revertedMatch)
    }

    @Transaction
    suspend fun recalculateTournamentStandings(tournamentId: Long) {
        val tournament = getTournamentById(tournamentId) ?: return
        val teams = getTeamsByTournamentOnce(tournamentId)
        val matches = getMatchesByTournamentOnce(tournamentId)

        val statsMap = teams.associateBy({ it.id }) { team ->
            team.copy(
                played = 0,
                won = 0,
                lost = 0,
                tiedOrAbandoned = 0,
                points = 0,
                runsFor = 0,
                ballsFaced = 0,
                runsAgainst = 0,
                ballsBowled = 0
            )
        }.toMutableMap()

        val maxBalls = tournament.oversPerMatch * 6

        for (match in matches) {
            if (match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED) continue
            val teamA = statsMap[match.teamAId] ?: continue
            val teamB = statsMap[match.teamBId] ?: continue

            if (match.status == MatchStatus.ABANDONED) {
                statsMap[teamA.id] = teamA.copy(
                    played = teamA.played + 1,
                    tiedOrAbandoned = teamA.tiedOrAbandoned + 1,
                    points = teamA.points + tournament.pointsAbandoned
                )
                statsMap[teamB.id] = teamB.copy(
                    played = teamB.played + 1,
                    tiedOrAbandoned = teamB.tiedOrAbandoned + 1,
                    points = teamB.points + tournament.pointsAbandoned
                )
                continue
            }

            // ICC NRR rule: if all out (10 wickets or >= squad), balls count as full quota
            val aBallsEff = if (match.teamAWickets >= 10) maxBalls else match.teamABalls.coerceAtLeast(1)
            val bBallsEff = if (match.teamBWickets >= 10) maxBalls else match.teamBBalls.coerceAtLeast(1)

            val aWon = match.teamARuns > match.teamBRuns
            val bWon = match.teamBRuns > match.teamARuns
            val tied = match.teamARuns == match.teamBRuns

            statsMap[teamA.id] = teamA.copy(
                played = teamA.played + 1,
                won = teamA.won + if (aWon) 1 else 0,
                lost = teamA.lost + if (bWon) 1 else 0,
                tiedOrAbandoned = teamA.tiedOrAbandoned + if (tied) 1 else 0,
                points = teamA.points + when {
                    aWon -> tournament.pointsWin
                    tied -> tournament.pointsTie
                    else -> tournament.pointsLoss
                },
                runsFor = teamA.runsFor + match.teamARuns,
                ballsFaced = teamA.ballsFaced + aBallsEff,
                runsAgainst = teamA.runsAgainst + match.teamBRuns,
                ballsBowled = teamA.ballsBowled + bBallsEff
            )

            statsMap[teamB.id] = teamB.copy(
                played = teamB.played + 1,
                won = teamB.won + if (bWon) 1 else 0,
                lost = teamB.lost + if (aWon) 1 else 0,
                tiedOrAbandoned = teamB.tiedOrAbandoned + if (tied) 1 else 0,
                points = teamB.points + when {
                    bWon -> tournament.pointsWin
                    tied -> tournament.pointsTie
                    else -> tournament.pointsLoss
                },
                runsFor = teamB.runsFor + match.teamBRuns,
                ballsFaced = teamB.ballsFaced + bBallsEff,
                runsAgainst = teamB.runsAgainst + match.teamARuns,
                ballsBowled = teamB.ballsBowled + aBallsEff
            )
        }

        for (updatedTeam in statsMap.values) {
            updateTeam(updatedTeam)
        }
    }

    @Transaction
    suspend fun finalizeMatch(
        matchId: Long,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        isAbandoned: Boolean = false
    ) {
        val match = getMatchById(matchId) ?: return
        val winnerId: Long
        val summary: String

        if (isAbandoned) {
            winnerId = 0L
            summary = "Match Abandoned (Points Shared)"
        } else if (match.teamARuns > match.teamBRuns) {
            winnerId = match.teamAId
            val margin = match.teamARuns - match.teamBRuns
            summary = "${match.teamAName} won by $margin runs"
        } else if (match.teamBRuns > match.teamARuns) {
            winnerId = match.teamBId
            val wicketsLeft = (10 - match.teamBWickets).coerceAtLeast(1)
            summary = "${match.teamBName} won by $wicketsLeft wickets"
        } else {
            winnerId = 0L
            summary = "Match Tied (${match.teamARuns}-${match.teamBRuns})"
        }

        val wasAlreadyFinal = match.status == MatchStatus.COMPLETED || match.status == MatchStatus.ABANDONED
        val balls = getBallEventsForMatchOnce(matchId)
        val tournamentPlayers = getPlayersByTournamentOnce(match.tournamentId)
        val dismissedIds = balls.filter { it.isWicket && it.dismissedPlayerId > 0L }
            .map { it.dismissedPlayerId }.toSet()

        val summaryRows = tournamentPlayers.mapNotNull { p ->
            val batEvents = balls.filter { it.strikerId == p.id }
            val bowlEvents = balls.filter { it.bowlerId == p.id }
            val batted = batEvents.isNotEmpty() || p.id in balls.map { it.nonStrikerId }
            val bowled = bowlEvents.isNotEmpty()
            if (!batted && !bowled) return@mapNotNull null
            val inningsNum = if (p.teamId == match.teamBId) 2 else 1
            PlayerMatchStatEntity(
                tournamentId = match.tournamentId,
                matchId = matchId,
                teamId = p.teamId,
                playerId = p.id,
                playerName = p.name,
                innings = inningsNum,
                didBat = batted,
                runsScored = batEvents.sumOf { it.runsOffBat },
                ballsFaced = batEvents.count { it.extraType != ExtraType.WIDE },
                fours = batEvents.count { it.isBoundaryFour },
                sixes = batEvents.count { it.isBoundarySix },
                isNotOut = batted && p.id !in dismissedIds,
                didBowl = bowled,
                ballsBowled = bowlEvents.count { CricketStatsEngine.isLegalDelivery(it.extraType) },
                runsConceded = bowlEvents.sumOf {
                    if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0
                    else it.runsOffBat + it.extraRuns
                },
                wicketsTaken = bowlEvents.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }
            )
        }

        val resolvedPomPair = when {
            isAbandoned -> 0L to ""
            playerOfMatchId > 0L -> playerOfMatchId to playerOfMatchName
            else -> {
                val autoStat = CricketStatsEngine.pickAutoManOfTheMatch(summaryRows, winnerId)?.first
                if (autoStat != null) {
                    autoStat.playerId to autoStat.playerName
                } else {
                    val fallback = tournamentPlayers.firstOrNull { it.teamId == winnerId }
                        ?: tournamentPlayers.firstOrNull { it.teamId == match.teamAId || it.teamId == match.teamBId }
                    (fallback?.id ?: 0L) to (fallback?.name ?: "")
                }
            }
        }
        val resolvedPomId = resolvedPomPair.first
        val resolvedPomName = resolvedPomPair.second

        updateMatch(
            match.copy(
                status = if (isAbandoned) MatchStatus.ABANDONED else MatchStatus.COMPLETED,
                winnerTeamId = winnerId,
                playerOfMatchId = resolvedPomId,
                playerOfMatchName = resolvedPomName,
                resultSummary = summary,
                updatedAt = System.currentTimeMillis()
            )
        )

        if (!wasAlreadyFinal) {
            val allInvolvedIds = (balls.flatMap { listOf(it.strikerId, it.nonStrikerId, it.bowlerId) } +
                listOf(resolvedPomId)).filter { it > 0L }.toSet()

            // Calculate per-match runs & bowling figures for career records
            val matchRunsByBatter = balls.groupBy { it.strikerId }
                .mapValues { (_, list) -> list.sumOf { it.runsOffBat } }
            val matchBowling = balls.groupBy { it.bowlerId }.mapValues { (_, list) ->
                val wkts = list.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }
                val r = list.sumOf {
                    if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0
                    else it.runsOffBat + it.extraRuns
                }
                wkts to r
            }

            for (p in tournamentPlayers) {
                val playedMatch = p.teamId == match.teamAId || p.teamId == match.teamBId
                if (!playedMatch && p.id !in allInvolvedIds) continue

                val batRuns = matchRunsByBatter[p.id]
                val batted = batRuns != null || p.id in balls.flatMap { listOf(it.strikerId, it.nonStrikerId) }
                val bowlStats = matchBowling[p.id]
                var newBestW = p.bestBowlingWickets
                var newBestR = p.bestBowlingRuns
                if (bowlStats != null) {
                    val (w, r) = bowlStats
                    if (w > newBestW || (w == newBestW && w > 0 && (newBestR == 0 || r < newBestR))) {
                        newBestW = w
                        newBestR = r
                    }
                }

                updatePlayer(
                    p.copy(
                        matchesPlayed = p.matchesPlayed + if (playedMatch) 1 else 0,
                        inningsBatted = p.inningsBatted + if (batted) 1 else 0,
                        notOuts = p.notOuts + if (batted && p.id !in dismissedIds) 1 else 0,
                        highestScore = maxOf(p.highestScore, batRuns ?: 0),
                        bestBowlingWickets = newBestW,
                        bestBowlingRuns = newBestR,
                        playerOfMatchCount = p.playerOfMatchCount + if (p.id == resolvedPomId) 1 else 0
                    )
                )
            }

            if (summaryRows.isNotEmpty()) {
                deletePlayerMatchStatsForMatch(matchId)
                insertPlayerMatchStats(summaryRows)
            }
        }

        recalculateTournamentStandings(match.tournamentId)
    }

    @Transaction
    suspend fun submitManualMatchScore(
        matchId: Long,
        teamARuns: Int,
        teamAWickets: Int,
        teamABalls: Int,
        teamAExtras: Int,
        teamBRuns: Int,
        teamBWickets: Int,
        teamBBalls: Int,
        teamBExtras: Int,
        playerStats: List<PlayerMatchStatEntity>,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        customResultText: String
    ) {
        val match = getMatchById(matchId) ?: return
        val winnerId = when {
            teamARuns > teamBRuns -> match.teamAId
            teamBRuns > teamARuns -> match.teamBId
            else -> 0L
        }
        val summary = customResultText.ifBlank {
            when {
                teamARuns > teamBRuns -> "${match.teamAName} won by ${teamARuns - teamBRuns} runs"
                teamBRuns > teamARuns -> "${match.teamBName} won by ${(10 - teamBWickets).coerceAtLeast(1)} wickets"
                else -> "Match Tied ($teamARuns-$teamBRuns)"
            }
        }

        val resolvedPom = if (playerOfMatchId > 0L) {
            playerOfMatchId to playerOfMatchName
        } else {
            val autoStat = CricketStatsEngine.pickAutoManOfTheMatch(playerStats, winnerId)?.first
            if (autoStat != null) autoStat.playerId to autoStat.playerName else 0L to ""
        }
        val finalPomId = resolvedPom.first
        val finalPomName = resolvedPom.second

        val wasAlreadyFinal = match.status == MatchStatus.COMPLETED || match.status == MatchStatus.ABANDONED

        updateMatch(
            match.copy(
                status = MatchStatus.COMPLETED,
                scoringMode = ScoringMode.MANUAL,
                teamARuns = teamARuns,
                teamAWickets = teamAWickets,
                teamABalls = teamABalls,
                teamAExtras = teamAExtras,
                teamBRuns = teamBRuns,
                teamBWickets = teamBWickets,
                teamBBalls = teamBBalls,
                teamBExtras = teamBExtras,
                winnerTeamId = winnerId,
                playerOfMatchId = finalPomId,
                playerOfMatchName = finalPomName,
                resultSummary = summary,
                updatedAt = System.currentTimeMillis()
            )
        )

        // Revert any previous manual stats if re-editing this match
        if (wasAlreadyFinal) {
            if (match.playerOfMatchId > 0L && match.playerOfMatchId != finalPomId) {
                getPlayerById(match.playerOfMatchId)?.let { oldPom ->
                    updatePlayer(oldPom.copy(playerOfMatchCount = (oldPom.playerOfMatchCount - 1).coerceAtLeast(0)))
                }
            }
            val prevStats = getPlayerMatchStatsOnce(matchId)
            for (prev in prevStats) {
                getPlayerById(prev.playerId)?.let { p ->
                    updatePlayer(
                        p.copy(
                            matchesPlayed = (p.matchesPlayed - 1).coerceAtLeast(0),
                            inningsBatted = (p.inningsBatted - if (prev.didBat) 1 else 0).coerceAtLeast(0),
                            runsScored = (p.runsScored - prev.runsScored).coerceAtLeast(0),
                            ballsFaced = (p.ballsFaced - prev.ballsFaced).coerceAtLeast(0),
                            fours = (p.fours - prev.fours).coerceAtLeast(0),
                            sixes = (p.sixes - prev.sixes).coerceAtLeast(0),
                            notOuts = (p.notOuts - if (prev.didBat && prev.isNotOut) 1 else 0).coerceAtLeast(0),
                            ballsBowled = (p.ballsBowled - prev.ballsBowled).coerceAtLeast(0),
                            runsConceded = (p.runsConceded - prev.runsConceded).coerceAtLeast(0),
                            wicketsTaken = (p.wicketsTaken - prev.wicketsTaken).coerceAtLeast(0)
                        )
                    )
                }
            }
        }

        deletePlayerMatchStatsForMatch(matchId)
        val nonEmptyStats = playerStats.filter {
            it.didBat || it.didBowl || it.runsScored > 0 || it.ballsFaced > 0 || it.ballsBowled > 0 || it.wicketsTaken > 0
        }
        if (nonEmptyStats.isNotEmpty()) {
            insertPlayerMatchStats(nonEmptyStats.map { it.copy(id = 0, matchId = matchId, tournamentId = match.tournamentId) })
        }

        val pomChanged = !wasAlreadyFinal || match.playerOfMatchId != finalPomId
        val updatedPlayerIds = mutableSetOf<Long>()
        for (stat in nonEmptyStats) {
            val p = getPlayerById(stat.playerId) ?: continue
            updatedPlayerIds.add(p.id)
            val betterBest = stat.wicketsTaken > p.bestBowlingWickets ||
                (stat.wicketsTaken == p.bestBowlingWickets && stat.wicketsTaken > 0 && (p.bestBowlingRuns == 0 || stat.runsConceded < p.bestBowlingRuns))
            val batted = stat.didBat || stat.runsScored > 0 || stat.ballsFaced > 0
            updatePlayer(
                p.copy(
                    matchesPlayed = p.matchesPlayed + 1,
                    inningsBatted = p.inningsBatted + if (batted) 1 else 0,
                    runsScored = p.runsScored + stat.runsScored,
                    ballsFaced = p.ballsFaced + stat.ballsFaced,
                    fours = p.fours + stat.fours,
                    sixes = p.sixes + stat.sixes,
                    notOuts = p.notOuts + if (batted && stat.isNotOut) 1 else 0,
                    highestScore = maxOf(p.highestScore, stat.runsScored),
                    ballsBowled = p.ballsBowled + stat.ballsBowled,
                    runsConceded = p.runsConceded + stat.runsConceded,
                    wicketsTaken = p.wicketsTaken + stat.wicketsTaken,
                    bestBowlingWickets = if (betterBest) stat.wicketsTaken else p.bestBowlingWickets,
                    bestBowlingRuns = if (betterBest) stat.runsConceded else p.bestBowlingRuns,
                    playerOfMatchCount = p.playerOfMatchCount + if (pomChanged && p.id == finalPomId) 1 else 0
                )
            )
        }

        if (pomChanged && finalPomId > 0L && finalPomId !in updatedPlayerIds) {
            getPlayerById(finalPomId)?.let { pom ->
                updatePlayer(pom.copy(playerOfMatchCount = pom.playerOfMatchCount + 1))
            }
        }

        recalculateTournamentStandings(match.tournamentId)
    }

    @Transaction
    suspend fun replaceTournamentBundle(
        tournament: TournamentEntity,
        teams: List<TeamEntity>,
        players: List<PlayerEntity>,
        matches: List<MatchEntity>,
        balls: List<BallEventEntity>,
        members: List<TournamentMemberEntity>,
        logs: List<AuditLogEntity>
    ): Long {
        val newTId = insertTournament(tournament.copy(id = 0))
        val teamIdMap = mutableMapOf<Long, Long>()
        for (t in teams) {
            val insertedTeamId = insertTeam(t.copy(id = 0, tournamentId = newTId))
            teamIdMap[t.id] = insertedTeamId
        }
        val playerIdMap = mutableMapOf<Long, Long>()
        for (p in players) {
            val mappedTeamId = teamIdMap[p.teamId] ?: continue
            val insertedPlayerId = insertPlayer(p.copy(id = 0, tournamentId = newTId, teamId = mappedTeamId))
            playerIdMap[p.id] = insertedPlayerId
        }
        val matchIdMap = mutableMapOf<Long, Long>()
        for (m in matches) {
            val mappedA = teamIdMap[m.teamAId] ?: m.teamAId
            val mappedB = teamIdMap[m.teamBId] ?: m.teamBId
            val insertedMatchId = insertMatch(
                m.copy(
                    id = 0,
                    tournamentId = newTId,
                    teamAId = mappedA,
                    teamBId = mappedB,
                    battingFirstTeamId = teamIdMap[m.battingFirstTeamId] ?: mappedA,
                    activeStrikerId = playerIdMap[m.activeStrikerId] ?: 0L,
                    activeNonStrikerId = playerIdMap[m.activeNonStrikerId] ?: 0L,
                    activeBowlerId = playerIdMap[m.activeBowlerId] ?: 0L,
                    winnerTeamId = teamIdMap[m.winnerTeamId] ?: 0L,
                    playerOfMatchId = playerIdMap[m.playerOfMatchId] ?: 0L
                )
            )
            matchIdMap[m.id] = insertedMatchId
        }
        for (b in balls) {
            val mappedMatchId = matchIdMap[b.matchId] ?: continue
            insertBallEvent(
                b.copy(
                    id = 0,
                    tournamentId = newTId,
                    matchId = mappedMatchId,
                    strikerId = playerIdMap[b.strikerId] ?: 0L,
                    nonStrikerId = playerIdMap[b.nonStrikerId] ?: 0L,
                    bowlerId = playerIdMap[b.bowlerId] ?: 0L,
                    dismissedPlayerId = playerIdMap[b.dismissedPlayerId] ?: 0L
                )
            )
        }
        for (mem in members) {
            insertMember(mem.copy(id = 0, tournamentId = newTId))
        }
        for (log in logs) {
            insertAuditLog(log.copy(id = 0, tournamentId = newTId))
        }
        return newTId
    }
}
