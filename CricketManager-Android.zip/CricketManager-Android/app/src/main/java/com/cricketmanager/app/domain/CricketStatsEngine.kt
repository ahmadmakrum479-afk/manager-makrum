package com.cricketmanager.app.domain

import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.WicketType
import java.util.Locale
import kotlin.math.abs

data class FantasyBreakdown(
    val battingPts: Int = 0,
    val bowlingPts: Int = 0,
    val bonusPts: Int = 0
) {
    val totalPts: Int get() = (battingPts + bowlingPts + bonusPts).coerceAtLeast(0)
}

object CricketStatsEngine {

    fun isLegalDelivery(extraType: ExtraType): Boolean {
        return extraType == ExtraType.NONE || extraType == ExtraType.BYE || extraType == ExtraType.LEG_BYE
    }

    fun formatOvers(legalBalls: Int): String {
        val safe = legalBalls.coerceAtLeast(0)
        return "${safe / 6}.${safe % 6}"
    }

    fun parseOversToBalls(oversInput: String): Int {
        val trimmed = oversInput.trim()
        if (trimmed.isEmpty()) return 0
        val parts = trimmed.split(".")
        val completedOvers = parts[0].toIntOrNull()?.coerceAtLeast(0) ?: 0
        val extraBalls = if (parts.size > 1) {
            parts[1].take(1).toIntOrNull()?.coerceIn(0, 5) ?: 0
        } else 0
        return completedOvers * 6 + extraBalls
    }

    fun calculateNetRunRate(
        runsFor: Int,
        ballsFaced: Int,
        runsAgainst: Int,
        ballsBowled: Int
    ): Double {
        val oversFor = if (ballsFaced > 0) ballsFaced / 6.0 else 0.0
        val oversAgainst = if (ballsBowled > 0) ballsBowled / 6.0 else 0.0
        val runRateFor = if (oversFor > 0.0) runsFor / oversFor else 0.0
        val runRateAgainst = if (oversAgainst > 0.0) runsAgainst / oversAgainst else 0.0
        return runRateFor - runRateAgainst
    }

    fun formatNrr(nrr: Double): String {
        val sign = if (nrr > 0.0005) "+" else if (nrr < -0.0005) "-" else ""
        return String.format(Locale.US, "%s%.3f", sign, abs(nrr))
    }

    fun calculateStrikeRate(runs: Int, balls: Int): Double {
        if (balls <= 0) return 0.0
        return (runs * 100.0) / balls
    }

    fun calculateBattingAverage(runs: Int, innings: Int, notOuts: Int): Double {
        val dismissals = (innings - notOuts).coerceAtLeast(0)
        return if (dismissals > 0) runs.toDouble() / dismissals else runs.toDouble()
    }

    fun calculateEconomyRate(runsConceded: Int, ballsBowled: Int): Double {
        if (ballsBowled <= 0) return 0.0
        return runsConceded / (ballsBowled / 6.0)
    }

    fun calculateBowlingAverage(runsConceded: Int, wickets: Int): Double {
        if (wickets <= 0) return 0.0
        return runsConceded.toDouble() / wickets
    }

    fun calculateRequiredRunRate(target: Int, currentRuns: Int, ballsBowled: Int, totalOvers: Int): Double {
        val runsNeeded = (target - currentRuns).coerceAtLeast(0)
        val ballsLeft = (totalOvers * 6 - ballsBowled).coerceAtLeast(1)
        return runsNeeded / (ballsLeft / 6.0)
    }

    fun calculateCurrentRunRate(runs: Int, ballsBowled: Int): Double {
        if (ballsBowled <= 0) return 0.0
        return runs / (ballsBowled / 6.0)
    }

    fun calculateMatchFantasyPoints(
        runsScored: Int,
        ballsFaced: Int,
        fours: Int,
        sixes: Int,
        isNotOut: Boolean,
        didBat: Boolean,
        ballsBowled: Int,
        runsConceded: Int,
        wicketsTaken: Int,
        wonMatch: Boolean
    ): FantasyBreakdown {
        var batPts = runsScored + fours + (sixes * 2)
        if (didBat && !isNotOut && runsScored == 0) {
            batPts -= 2
        }
        val milestonePts = when {
            runsScored >= 100 -> 40
            runsScored >= 50 -> 20
            runsScored >= 30 -> 10
            else -> 0
        }
        val sr = calculateStrikeRate(runsScored, ballsFaced)
        val srBonus = if (ballsFaced >= 6) {
            when {
                sr >= 200.0 -> 10
                sr >= 150.0 -> 6
                sr >= 120.0 -> 3
                else -> 0
            }
        } else 0

        val bowlPts = wicketsTaken * 25
        val haulBonus = when {
            wicketsTaken >= 5 -> 25
            wicketsTaken >= 3 -> 12
            else -> 0
        }
        val econ = calculateEconomyRate(runsConceded, ballsBowled)
        val econBonus = if (ballsBowled >= 6) {
            when {
                econ <= 4.5 -> 10
                econ <= 6.5 -> 5
                else -> 0
            }
        } else 0

        val notOutFinisherBonus = if (didBat && isNotOut && runsScored >= 10) 3 else 0
        val winBonus = if (wonMatch && (didBat || ballsBowled > 0 || wicketsTaken > 0 || runsScored > 0)) 5 else 0

        return FantasyBreakdown(
            battingPts = (batPts + milestonePts + srBonus).coerceAtLeast(0),
            bowlingPts = bowlPts + haulBonus + econBonus,
            bonusPts = notOutFinisherBonus + winBonus
        )
    }

    fun pickAutoManOfTheMatch(
        stats: List<PlayerMatchStatEntity>,
        winningTeamId: Long
    ): Pair<PlayerMatchStatEntity, Int>? {
        return stats.map { st ->
            val breakdown = calculateMatchFantasyPoints(
                runsScored = st.runsScored,
                ballsFaced = st.ballsFaced,
                fours = st.fours,
                sixes = st.sixes,
                isNotOut = st.isNotOut,
                didBat = st.didBat || st.runsScored > 0 || st.ballsFaced > 0,
                ballsBowled = st.ballsBowled,
                runsConceded = st.runsConceded,
                wicketsTaken = st.wicketsTaken,
                wonMatch = winningTeamId > 0L && st.teamId == winningTeamId
            )
            st to breakdown.totalPts
        }.maxWithOrNull(
            compareBy<Pair<PlayerMatchStatEntity, Int>> { it.second }
                .thenBy { it.first.runsScored + it.first.wicketsTaken * 20 }
        )
    }

    fun calculateBallEventsFantasyMap(
        players: List<PlayerEntity>,
        balls: List<BallEventEntity>,
        winningTeamId: Long
    ): List<Pair<PlayerEntity, FantasyBreakdown>> {
        val dismissedIds = balls.filter { it.isWicket && it.dismissedPlayerId > 0L }
            .map { it.dismissedPlayerId }.toSet()
        val nonStrikerIds = balls.map { it.nonStrikerId }.toSet()

        return players.map { p ->
            val batBalls = balls.filter { it.strikerId == p.id }
            val bowlBalls = balls.filter { it.bowlerId == p.id }
            val didBat = batBalls.isNotEmpty() || p.id in nonStrikerIds
            val runs = batBalls.sumOf { it.runsOffBat }
            val ballsFaced = batBalls.count { it.extraType != ExtraType.WIDE }
            val fours = batBalls.count { it.isBoundaryFour }
            val sixes = batBalls.count { it.isBoundarySix }
            val legalBowled = bowlBalls.count { isLegalDelivery(it.extraType) }
            val conceded = bowlBalls.sumOf {
                if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0
                else it.runsOffBat + it.extraRuns
            }
            val wkts = bowlBalls.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }

            val breakdown = calculateMatchFantasyPoints(
                runsScored = runs,
                ballsFaced = ballsFaced,
                fours = fours,
                sixes = sixes,
                isNotOut = didBat && p.id !in dismissedIds,
                didBat = didBat,
                ballsBowled = legalBowled,
                runsConceded = conceded,
                wicketsTaken = wkts,
                wonMatch = winningTeamId > 0L && p.teamId == winningTeamId
            )
            p to breakdown
        }.sortedWith(
            compareByDescending<Pair<PlayerEntity, FantasyBreakdown>> { it.second.totalPts }
                .thenByDescending { it.first.runsScored + it.first.wicketsTaken * 20 }
        )
    }

    fun calculateTournamentFantasyBreakdown(
        player: PlayerEntity,
        allMatchStats: List<PlayerMatchStatEntity>,
        allMatches: List<MatchEntity>
    ): FantasyBreakdown {
        val pStats = allMatchStats.filter { it.playerId == player.id }
        val matchMap = allMatches.associateBy { it.id }

        // Always base core batting/bowling points on career entity totals so direct edits also count
        val baseBatPts = player.runsScored + player.fours + (player.sixes * 2)
        val baseBowlPts = player.wicketsTaken * 25

        var milestoneAndRateBatBonus = 0
        var haulAndEconBowlBonus = 0
        var winAndNotOutBonus = 0

        if (pStats.isNotEmpty()) {
            pStats.forEach { st ->
                val wonMatch = (matchMap[st.matchId]?.winnerTeamId ?: 0L) == st.teamId
                milestoneAndRateBatBonus += when {
                    st.runsScored >= 100 -> 40
                    st.runsScored >= 50 -> 20
                    st.runsScored >= 30 -> 10
                    else -> 0
                }
                if (st.ballsFaced >= 6) {
                    val sr = calculateStrikeRate(st.runsScored, st.ballsFaced)
                    milestoneAndRateBatBonus += when {
                        sr >= 200.0 -> 10
                        sr >= 150.0 -> 6
                        sr >= 120.0 -> 3
                        else -> 0
                    }
                }
                haulAndEconBowlBonus += when {
                    st.wicketsTaken >= 5 -> 25
                    st.wicketsTaken >= 3 -> 12
                    else -> 0
                }
                if (st.ballsBowled >= 6) {
                    val econ = calculateEconomyRate(st.runsConceded, st.ballsBowled)
                    haulAndEconBowlBonus += when {
                        econ <= 4.5 -> 10
                        econ <= 6.5 -> 5
                        else -> 0
                    }
                }
                if (st.didBat && st.isNotOut && st.runsScored >= 10) winAndNotOutBonus += 3
                if (wonMatch && (st.didBat || st.didBowl || st.runsScored > 0 || st.wicketsTaken > 0)) {
                    winAndNotOutBonus += 5
                }
            }
        } else {
            if (player.highestScore >= 50) milestoneAndRateBatBonus += 20
            else if (player.highestScore >= 30) milestoneAndRateBatBonus += 10
            if (player.bestBowlingWickets >= 5) haulAndEconBowlBonus += 25
            else if (player.bestBowlingWickets >= 3) haulAndEconBowlBonus += 12
            winAndNotOutBonus += player.notOuts * 3
        }

        val pomBonus = player.playerOfMatchCount * 20
        return FantasyBreakdown(
            battingPts = baseBatPts + milestoneAndRateBatBonus,
            bowlingPts = baseBowlPts + haulAndEconBowlBonus,
            bonusPts = winAndNotOutBonus + pomBonus
        )
    }

    fun calculateMvpScore(player: PlayerEntity): Double {
        return (player.runsScored * 1.0 +
            player.fours * 1.0 +
            player.sixes * 2.0 +
            player.wicketsTaken * 25.0 +
            player.notOuts * 3.0 +
            player.playerOfMatchCount * 20.0)
    }

    fun formatBallChip(
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean
    ): String {
        if (isWicket) {
            return if (runsOffBat > 0) "${runsOffBat}+W" else "W"
        }
        return when (extraType) {
            ExtraType.NONE -> if (runsOffBat == 0) "•" else runsOffBat.toString()
            ExtraType.WIDE -> if (extraRuns > 1 || runsOffBat > 0) "${runsOffBat + extraRuns}Wd" else "Wd"
            ExtraType.NO_BALL -> if (runsOffBat > 0) "${runsOffBat}NB" else "NB"
            ExtraType.BYE -> "${runsOffBat + extraRuns}B"
            ExtraType.LEG_BYE -> "${runsOffBat + extraRuns}LB"
        }
    }

    fun generateFixtures(
        tournamentId: Long,
        teams: List<TeamEntity>,
        format: TournamentFormat,
        oversPerMatch: Int,
        scoringMode: ScoringMode,
        venue: String,
        startDateLabel: String,
        startingMatchNumber: Int = 1
    ): List<MatchEntity> {
        if (teams.size < 2) return emptyList()
        val fixtures = mutableListOf<MatchEntity>()
        var matchNo = startingMatchNumber

        when (format) {
            TournamentFormat.LEAGUE, TournamentFormat.ROUND_ROBIN -> {
                for (i in teams.indices) {
                    for (j in i + 1 until teams.size) {
                        val a = teams[i]
                        val b = teams[j]
                        fixtures.add(
                            MatchEntity(
                                tournamentId = tournamentId,
                                matchNumber = matchNo++,
                                stage = MatchStage.LEAGUE,
                                groupName = "League",
                                teamAId = a.id,
                                teamBId = b.id,
                                teamAName = a.name,
                                teamBName = b.name,
                                venue = venue,
                                scheduledDate = startDateLabel,
                                scheduledTime = "${10 + ((matchNo - 1) % 6)}:00",
                                oversLimit = oversPerMatch,
                                scoringMode = scoringMode,
                                status = MatchStatus.UPCOMING
                            )
                        )
                    }
                }
            }

            TournamentFormat.GROUP_KNOCKOUT -> {
                val grouped = teams.groupBy { it.groupName.ifBlank { "Group A" } }
                grouped.forEach { (group, groupTeams) ->
                    for (i in groupTeams.indices) {
                        for (j in i + 1 until groupTeams.size) {
                            val a = groupTeams[i]
                            val b = groupTeams[j]
                            fixtures.add(
                                MatchEntity(
                                    tournamentId = tournamentId,
                                    matchNumber = matchNo++,
                                    stage = MatchStage.GROUP,
                                    groupName = group,
                                    teamAId = a.id,
                                    teamBId = b.id,
                                    teamAName = a.name,
                                    teamBName = b.name,
                                    venue = venue,
                                    scheduledDate = startDateLabel,
                                    scheduledTime = "${10 + ((matchNo - 1) % 6)}:00",
                                    oversLimit = oversPerMatch,
                                    scoringMode = scoringMode,
                                    status = MatchStatus.UPCOMING
                                )
                            )
                        }
                    }
                }
            }

            TournamentFormat.KNOCKOUT -> {
                var idx = 0
                while (idx + 1 < teams.size) {
                    val a = teams[idx]
                    val b = teams[idx + 1]
                    fixtures.add(
                        MatchEntity(
                            tournamentId = tournamentId,
                            matchNumber = matchNo++,
                            stage = MatchStage.KNOCKOUT,
                            groupName = "Knockout",
                            teamAId = a.id,
                            teamBId = b.id,
                            teamAName = a.name,
                            teamBName = b.name,
                            venue = venue,
                            scheduledDate = startDateLabel,
                            scheduledTime = "${14 + ((matchNo - 1) % 4)}:00",
                            oversLimit = oversPerMatch,
                            scoringMode = scoringMode,
                            status = MatchStatus.UPCOMING
                        )
                    )
                    idx += 2
                }
            }
        }
        return fixtures
    }

    fun sortTeamsForPointsTable(teams: List<TeamEntity>): List<TeamEntity> {
        return teams.sortedWith(
            compareByDescending<TeamEntity> { it.points }
                .thenByDescending { it.won }
                .thenByDescending {
                    calculateNetRunRate(it.runsFor, it.ballsFaced, it.runsAgainst, it.ballsBowled)
                }
                .thenBy { it.name }
        )
    }
}
