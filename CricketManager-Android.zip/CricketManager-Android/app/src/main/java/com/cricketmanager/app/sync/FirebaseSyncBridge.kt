package com.cricketmanager.app.sync

import android.content.Context
import com.cricketmanager.app.data.local.TournamentEntity
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed class CloudSyncResult {
    data class Synced(val syncedCount: Int) : CloudSyncResult()
    data object NotConfigured : CloudSyncResult()
    data class Error(val message: String) : CloudSyncResult()
}

class FirebaseSyncBridge(private val context: Context) {

    fun isFirebaseConfigured(): Boolean {
        return runCatching { FirebaseApp.getApps(context).isNotEmpty() }.getOrDefault(false)
    }

    suspend fun signInOrRegisterFirebase(email: String, password: String): Result<String> {
        if (!isFirebaseConfigured()) {
            return Result.failure(IllegalStateException("google-services.json not configured"))
        }
        return runCatching {
            val auth = FirebaseAuth.getInstance()
            val result = try {
                awaitTask(auth.signInWithEmailAndPassword(email, password))
            } catch (_: Exception) {
                awaitTask(auth.createUserWithEmailAndPassword(email, password))
            }
            result.user?.uid ?: "anonymous"
        }
    }

    suspend fun pushDirtyTournaments(
        tournaments: List<TournamentEntity>,
        ownerUid: String
    ): CloudSyncResult {
        if (!isFirebaseConfigured()) {
            return CloudSyncResult.NotConfigured
        }
        return try {
            val firestore = FirebaseFirestore.getInstance()
            var count = 0
            for (t in tournaments) {
                val payload = mapOf(
                    "localId" to t.id,
                    "name" to t.name,
                    "logoEmoji" to t.logoEmoji,
                    "pitchType" to t.pitchType.name,
                    "scoringMode" to t.scoringMode.name,
                    "format" to t.format.name,
                    "oversPerMatch" to t.oversPerMatch,
                    "tournamentCode" to t.tournamentCode,
                    "editorCode" to t.editorCode,
                    "viewerCode" to t.viewerCode,
                    "ownerUid" to ownerUid,
                    "updatedAt" to t.updatedAt
                )
                awaitTask(
                    firestore.collection("tournaments")
                        .document(t.tournamentCode)
                        .set(payload, SetOptions.merge())
                )
                count++
            }
            CloudSyncResult.Synced(count)
        } catch (e: Exception) {
            CloudSyncResult.Error(e.message ?: "Cloud sync error")
        }
    }

    private suspend fun <T> awaitTask(task: Task<T>): T = suspendCancellableCoroutine { cont ->
        task.addOnSuccessListener { result ->
            if (cont.isActive) cont.resume(result)
        }.addOnFailureListener { ex ->
            if (cont.isActive) cont.resumeWithException(ex)
        }
    }
}
