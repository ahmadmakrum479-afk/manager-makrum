package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@Composable
fun TournamentDetailsScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onOpenTeams: () -> Unit,
    onOpenPlayers: () -> Unit,
    onOpenSchedule: () -> Unit,
    onOpenPoints: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    val strings = LocalAppStrings.current
    val clipboard = LocalClipboardManager.current
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId } ?: uiState.selectedTournament

    LaunchedEffect(tournamentId) {
        if (tournamentId > 0L) viewModel.selectTournament(tournamentId)
    }

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = tournament?.let { "${it.logoEmoji} ${it.name}" } ?: strings.tournamentDetails,
                subtitle = tournament?.let { "${it.format.labelEn} · ${it.scoringMode.labelEn}" },
                onBack = onBack
            )
        }
    ) { padding ->
        if (tournament == null) {
            Column(modifier = Modifier.padding(padding).padding(20.dp)) {
                Text(strings.noTournamentsYet)
            }
            return@Scaffold
        }

        val perms = uiState.permissionsFor(tournament.id)
        val teamCount = uiState.allTeams.count { it.tournamentId == tournament.id }
        val playerCount = uiState.allPlayers.count { it.tournamentId == tournament.id }
        val matchCount = uiState.allMatches.count { it.tournamentId == tournament.id }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "${tournament.organizationName.ifBlank { "Cricket Organizer" }} · ${tournament.location}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${tournament.pitchType.labelEn} · ${tournament.oversPerMatch} Overs · Win ${tournament.pointsWin} / Tie ${tournament.pointsTie}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (tournament.rulesSummary.isNotBlank()) {
                            Text(
                                text = tournament.rulesSummary,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Join Code: ${tournament.tournamentCode}  |  Viewer: ${tournament.viewerCode}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(tournament.tournamentCode))
                                }
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy code")
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HubTile(
                        title = strings.teams,
                        subtitle = "$teamCount Teams",
                        icon = Icons.Rounded.Groups,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTeams
                    )
                    HubTile(
                        title = strings.players,
                        subtitle = "$playerCount Players",
                        icon = Icons.Rounded.Person,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPlayers
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HubTile(
                        title = strings.schedule,
                        subtitle = "$matchCount Matches",
                        icon = Icons.Rounded.CalendarMonth,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenSchedule
                    )
                    HubTile(
                        title = strings.pointsTable,
                        subtitle = "Standings & NRR",
                        icon = Icons.Rounded.Leaderboard,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPoints
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HubTile(
                        title = strings.statistics,
                        subtitle = "MVP & Leaderboards",
                        icon = Icons.Rounded.BarChart,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenStats
                    )
                    HubTile(
                        title = strings.permissions,
                        subtitle = "Role: ${perms.role.labelEn}",
                        icon = Icons.Rounded.AdminPanelSettings,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPermissions
                    )
                }
            }

            if (perms.canEditSchedule) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "Knockout Stage Generator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { viewModel.generateStage(tournament, MatchStage.SEMI_FINAL) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(strings.generateSemiFinal)
                                }
                                Button(
                                    onClick = { viewModel.generateStage(tournament, MatchStage.FINAL) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(strings.generateFinal)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HubTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
