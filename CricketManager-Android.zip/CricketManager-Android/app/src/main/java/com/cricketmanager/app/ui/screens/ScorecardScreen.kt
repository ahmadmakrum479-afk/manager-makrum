package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import java.util.Locale

@Composable
fun ScorecardScreen(
    matchId: Long,
    uiState: CricketUiState,
    onBack: () -> Unit,
    onOpenLiveScoring: () -> Unit,
    onOpenManualScoring: () -> Unit
) {
    val strings = LocalAppStrings.current
    val match = uiState.allMatches.firstOrNull { it.id == matchId }

    if (match == null) {
        Scaffold(topBar = { ScreenTopBar(title = strings.scorecard, onBack = onBack) }) { p ->
            Text("Match not found", modifier = Modifier.padding(p).padding(20.dp))
        }
        return
    }

    val players = uiState.allPlayers.filter { it.tournamentId == match.tournamentId }
    val balls = uiState.allBallEvents.filter { it.matchId == match.id }
    val manualStats = uiState.allPlayerMatchStats.filter { it.matchId == match.id }
    val perms = uiState.permissionsFor(match.tournamentId)

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = strings.scorecard,
                subtitle = "${match.teamAName} vs ${match.teamBName}",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Match #${match.matchNumber} · ${match.stage.labelEn}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(match.teamAName, fontWeight = FontWeight.Bold)
                            Text("${match.teamARuns}/${match.teamAWickets} (${CricketStatsEngine.formatOvers(match.teamABalls)} ov) · Ext ${match.teamAExtras}", fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(match.teamBName, fontWeight = FontWeight.Bold)
                            Text("${match.teamBRuns}/${match.teamBWickets} (${CricketStatsEngine.formatOvers(match.teamBBalls)} ov) · Ext ${match.teamBExtras}", fontWeight = FontWeight.Bold)
                        }
                        Text(match.resultSummary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        if (match.playerOfMatchName.isNotBlank()) {
                            val pomStat = manualStats.firstOrNull { it.playerId == match.playerOfMatchId }
                            val pomFantasy = if (pomStat != null) {
                                CricketStatsEngine.calculateMatchFantasyPoints(
                                    runsScored = pomStat.runsScored,
                                    ballsFaced = pomStat.ballsFaced,
                                    fours = pomStat.fours,
                                    sixes = pomStat.sixes,
                                    isNotOut = pomStat.isNotOut,
                                    didBat = pomStat.didBat,
                                    ballsBowled = pomStat.ballsBowled,
                                    runsConceded = pomStat.runsConceded,
                                    wicketsTaken = pomStat.wicketsTaken,
                                    wonMatch = match.winnerTeamId > 0L && pomStat.teamId == match.winnerTeamId
                                ).totalPts
                            } else 0
                            val ptsSuffix = if (pomFantasy > 0) " ($pomFantasy Fantasy Pts)" else ""
                            Text("⭐ Man of the Match: ${match.playerOfMatchName}$ptsSuffix", style = MaterialTheme.typography.labelMedium)
                        }
                        if (perms.canScore) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                if (match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED) {
                                    Button(onClick = onOpenLiveScoring, modifier = Modifier.weight(1f)) {
                                        Text(strings.liveScoring)
                                    }
                                }
                                OutlinedButton(onClick = onOpenManualScoring, modifier = Modifier.weight(1f)) {
                                    Text("Edit Scorecard")
                                }
                            }
                        }
                    }
                }
            }

            item {
                InningsBreakdownCard(
                    title = "${match.teamAName} — 1st Innings",
                    inningsBalls = balls.filter { it.innings == 1 },
                    battingTeamStats = manualStats.filter { it.teamId == match.teamAId },
                    bowlingTeamStats = manualStats.filter { it.teamId == match.teamBId },
                    players = players
                )
            }

            item {
                InningsBreakdownCard(
                    title = "${match.teamBName} — 2nd Innings",
                    inningsBalls = balls.filter { it.innings == 2 },
                    battingTeamStats = manualStats.filter { it.teamId == match.teamBId },
                    bowlingTeamStats = manualStats.filter { it.teamId == match.teamAId },
                    players = players
                )
            }
        }
    }
}

@Composable
private fun InningsBreakdownCard(
    title: String,
    inningsBalls: List<BallEventEntity>,
    battingTeamStats: List<PlayerMatchStatEntity>,
    bowlingTeamStats: List<PlayerMatchStatEntity>,
    players: List<PlayerEntity>
) {
    val hasManualBat = battingTeamStats.any { it.didBat || it.runsScored > 0 || it.ballsFaced > 0 }
    val hasManualBowl = bowlingTeamStats.any { it.didBowl || it.ballsBowled > 0 || it.wicketsTaken > 0 }

    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (!hasManualBat && !hasManualBowl && inningsBalls.isEmpty()) {
                Text("No individual player stats recorded yet. Tap Edit Scorecard to add.", style = MaterialTheme.typography.bodySmall)
                return@Column
            }

            Text("Batting", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (hasManualBat) {
                battingTeamStats.filter { it.didBat || it.runsScored > 0 || it.ballsFaced > 0 }.forEach { st ->
                    val sr = CricketStatsEngine.calculateStrikeRate(st.runsScored, st.ballsFaced)
                    val notOutMark = if (st.isNotOut) "*" else ""
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${st.playerName}$notOutMark", modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%d (%d)  4s:%d 6s:%d  SR:%.1f", st.runsScored, st.ballsFaced, st.fours, st.sixes, sr),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                val batters = inningsBalls.groupBy { it.strikerId }.filterKeys { it > 0L }
                batters.forEach { (batterId, list) ->
                    val name = players.firstOrNull { it.id == batterId }?.name ?: "Batter"
                    val runs = list.sumOf { it.runsOffBat }
                    val ballsFaced = list.count { it.extraType != ExtraType.WIDE }
                    val fours = list.count { it.isBoundaryFour }
                    val sixes = list.count { it.isBoundarySix }
                    val sr = CricketStatsEngine.calculateStrikeRate(runs, ballsFaced)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%d (%d)  4s:%d 6s:%d  SR:%.1f", runs, ballsFaced, fours, sixes, sr),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            HorizontalDivider()
            Text("Bowling", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (hasManualBowl) {
                bowlingTeamStats.filter { it.didBowl || it.ballsBowled > 0 || it.wicketsTaken > 0 }.forEach { st ->
                    val econ = CricketStatsEngine.calculateEconomyRate(st.runsConceded, st.ballsBowled)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(st.playerName, modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%s ov  %d-%d  Econ:%.2f", CricketStatsEngine.formatOvers(st.ballsBowled), st.wicketsTaken, st.runsConceded, econ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            } else {
                val bowlers = inningsBalls.groupBy { it.bowlerId }.filterKeys { it > 0L }
                bowlers.forEach { (bowlerId, list) ->
                    val name = players.firstOrNull { it.id == bowlerId }?.name ?: "Bowler"
                    val legalBalls = list.count { CricketStatsEngine.isLegalDelivery(it.extraType) }
                    val conceded = list.sumOf {
                        if (it.extraType == ExtraType.BYE || it.extraType == ExtraType.LEG_BYE) 0 else it.runsOffBat + it.extraRuns
                    }
                    val wkts = list.count { it.isWicket && it.wicketType != WicketType.RUN_OUT }
                    val econ = CricketStatsEngine.calculateEconomyRate(conceded, legalBalls)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, modifier = Modifier.weight(1f))
                        Text(
                            String.format(Locale.US, "%s ov  %d-%d  Econ:%.2f", CricketStatsEngine.formatOvers(legalBalls), wkts, conceded, econ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
