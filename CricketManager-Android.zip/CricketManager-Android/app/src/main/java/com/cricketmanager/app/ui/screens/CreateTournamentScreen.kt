package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.repository.TeamDraft
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateTournamentScreen(
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onCreated: (Long) -> Unit
) {
    val strings = LocalAppStrings.current
    val isBn = strings.language == AppLanguage.BN

    var name by remember { mutableStateOf("") }
    var logoEmoji by remember { mutableStateOf("🏆") }
    var orgName by remember { mutableStateOf(uiState.activeUser?.organization ?: "") }
    var location by remember { mutableStateOf("Central Ground") }
    var startDate by remember { mutableStateOf("2026-05-15") }
    var oversText by remember { mutableStateOf("10") }
    var rules by remember { mutableStateOf("ICC standard rules. Wide & No-ball = 1 run.") }
    var pointsWinText by remember { mutableStateOf("2") }
    var pointsTieText by remember { mutableStateOf("1") }
    var pointsLossText by remember { mutableStateOf("0") }
    var pointsAbandonText by remember { mutableStateOf("1") }

    var pitchType by remember { mutableStateOf(PitchType.FULL_PITCH) }
    var scoringMode by remember { mutableStateOf(ScoringMode.BALL_BY_BALL) }
    var format by remember { mutableStateOf(TournamentFormat.LEAGUE) }

    val teamDrafts = remember {
        mutableStateListOf(
            TeamDraft("Royal Tigers", "RYT", "🐯", "Captain 1", "Group A"),
            TeamDraft("Green Falcons", "GRF", "🦅", "Captain 2", "Group A"),
            TeamDraft("City Strikers", "CTS", "⚡", "Captain 3", "Group B"),
            TeamDraft("Metro Kings", "MTK", "👑", "Captain 4", "Group B")
        )
    }

    var newTeamName by remember { mutableStateOf("") }
    var newTeamCaptain by remember { mutableStateOf("") }
    var newTeamGroup by remember { mutableStateOf("Group A") }

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = strings.createTournament,
                subtitle = if (isBn) "টুর্নামেন্ট, দল ও নিয়ম সেট করুন" else "Configure rules, format, scoring & teams",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBn) "১. টুর্নামেন্টের তথ্য" else "1. Tournament Identity",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = logoEmoji,
                                onValueChange = { logoEmoji = it.take(2) },
                                label = { Text("Logo") },
                                modifier = Modifier.weight(0.25f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text(if (isBn) "টুর্নামেন্টের নাম *" else "Tournament Name *") },
                                modifier = Modifier.weight(0.75f),
                                singleLine = true
                            )
                        }
                        OutlinedTextField(
                            value = orgName,
                            onValueChange = { orgName = it },
                            label = { Text(strings.organization) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = location,
                                onValueChange = { location = it },
                                label = { Text(if (isBn) "মাঠের নাম" else "Venue") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = startDate,
                                onValueChange = { startDate = it },
                                label = { Text(if (isBn) "শুরুর তারিখ" else "Start Date") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBn) "২. পিচ, স্কোরিং ও ফরম্যাট" else "2. Pitch, Scoring & Format",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(if (isBn) "পিচের ধরন" else "Pitch Type", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PitchType.entries.forEach { pt ->
                                FilterChip(
                                    selected = pitchType == pt,
                                    onClick = { pitchType = pt },
                                    label = { Text(if (isBn) pt.labelBn else pt.labelEn) }
                                )
                            }
                        }

                        Text(if (isBn) "স্কোরিং ব্যবস্থা" else "Scoring Mode", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScoringMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = scoringMode == mode,
                                    onClick = { scoringMode = mode },
                                    label = { Text(if (isBn) mode.labelBn else mode.labelEn) }
                                )
                            }
                        }

                        Text(if (isBn) "টুর্নামেন্ট ফরম্যাট" else "Tournament Format", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TournamentFormat.entries.forEach { fmt ->
                                FilterChip(
                                    selected = format == fmt,
                                    onClick = { format = fmt },
                                    label = { Text(if (isBn) fmt.labelBn else fmt.labelEn) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = oversText,
                            onValueChange = { oversText = it.filter { ch -> ch.isDigit() } },
                            label = { Text(if (isBn) "ম্যাচ প্রতি ওভার সংখ্যা" else "Overs per Match") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = rules,
                            onValueChange = { rules = it },
                            label = { Text(if (isBn) "খেলার নিয়মাবলি" else "Match Rules") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        Text(if (isBn) "পয়েন্ট পদ্ধতি (জয় / টাই / হার / পরিত্যক্ত)" else "Points System (Win / Tie / Loss / Abandoned)", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = pointsWinText,
                                onValueChange = { pointsWinText = it.filter { c -> c.isDigit() } },
                                label = { Text("Win") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsTieText,
                                onValueChange = { pointsTieText = it.filter { c -> c.isDigit() } },
                                label = { Text("Tie") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsLossText,
                                onValueChange = { pointsLossText = it.filter { c -> c.isDigit() } },
                                label = { Text("Loss") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = pointsAbandonText,
                                onValueChange = { pointsAbandonText = it.filter { c -> c.isDigit() } },
                                label = { Text("NR") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (isBn) "৩. অংশগ্রহণকারী দল (${teamDrafts.size})" else "3. Participating Teams (${teamDrafts.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newTeamName,
                                onValueChange = { newTeamName = it },
                                label = { Text(if (isBn) "দলের নাম" else "Team Name") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = newTeamCaptain,
                                onValueChange = { newTeamCaptain = it },
                                label = { Text(if (isBn) "অধিনায়ক" else "Captain") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newTeamGroup,
                                onValueChange = { newTeamGroup = it },
                                label = { Text("Group") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedButton(
                                onClick = {
                                    if (newTeamName.isNotBlank()) {
                                        val code = newTeamName.trim().take(3).uppercase()
                                        teamDrafts.add(
                                            TeamDraft(
                                                name = newTeamName.trim(),
                                                shortCode = code,
                                                logoEmoji = "🏏",
                                                captainName = newTeamCaptain.trim(),
                                                groupName = newTeamGroup.trim().ifBlank { "Group A" }
                                            )
                                        )
                                        newTeamName = ""
                                        newTeamCaptain = ""
                                    }
                                }
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null)
                                Text(strings.addTeam)
                            }
                        }
                    }
                }
            }

            itemsIndexed(teamDrafts) { index, draft ->
                Card(shape = RoundedCornerShape(12.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${draft.logoEmoji} ${draft.name} (${draft.shortCode})", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${draft.groupName} · Capt: ${draft.captainName.ifBlank { "TBD" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (teamDrafts.size > 2) {
                            IconButton(onClick = { teamDrafts.removeAt(index) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = strings.delete)
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (name.isNotBlank() && teamDrafts.size >= 2) {
                            viewModel.createTournament(
                                name = name,
                                logoEmoji = logoEmoji,
                                organizationName = orgName,
                                pitchType = pitchType,
                                scoringMode = scoringMode,
                                format = format,
                                oversPerMatch = oversText.toIntOrNull() ?: 10,
                                groupCount = 2,
                                rulesSummary = rules,
                                pointsWin = pointsWinText.toIntOrNull() ?: 2,
                                pointsTie = pointsTieText.toIntOrNull() ?: 1,
                                pointsLoss = pointsLossText.toIntOrNull() ?: 0,
                                pointsAbandoned = pointsAbandonText.toIntOrNull() ?: 1,
                                location = location,
                                startDateLabel = startDate,
                                teamDrafts = teamDrafts.toList(),
                                onCreated = onCreated
                            )
                        }
                    },
                    enabled = name.isNotBlank() && teamDrafts.size >= 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text(strings.createTournament)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
