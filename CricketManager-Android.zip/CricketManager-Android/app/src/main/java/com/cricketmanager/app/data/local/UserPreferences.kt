package com.cricketmanager.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "cricket_manager_prefs")

class UserPreferences(private val context: Context) {

    private object Keys {
        val ACTIVE_USER_ID = longPreferencesKey("active_user_id")
        val SELECTED_TOURNAMENT_ID = longPreferencesKey("selected_tournament_id")
        val LANGUAGE = stringPreferencesKey("app_language")
        val AUTO_SYNC = booleanPreferencesKey("auto_sync")
        val LAST_SYNC_AT = longPreferencesKey("last_sync_at")
    }

    val activeUserIdFlow: Flow<Long> = context.dataStore.data.map { it[Keys.ACTIVE_USER_ID] ?: 0L }
    val selectedTournamentIdFlow: Flow<Long> = context.dataStore.data.map { it[Keys.SELECTED_TOURNAMENT_ID] ?: 0L }
    val languageCodeFlow: Flow<String> = context.dataStore.data.map { it[Keys.LANGUAGE] ?: "BN" }
    val autoSyncFlow: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_SYNC] ?: true }
    val lastSyncAtFlow: Flow<Long> = context.dataStore.data.map { it[Keys.LAST_SYNC_AT] ?: 0L }

    suspend fun setActiveUserId(userId: Long) {
        context.dataStore.edit { it[Keys.ACTIVE_USER_ID] = userId }
    }

    suspend fun setSelectedTournamentId(tournamentId: Long) {
        context.dataStore.edit { it[Keys.SELECTED_TOURNAMENT_ID] = tournamentId }
    }

    suspend fun setLanguageCode(code: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = code }
    }

    suspend fun setAutoSync(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SYNC] = enabled }
    }

    suspend fun setLastSyncAt(timestamp: Long) {
        context.dataStore.edit { it[Keys.LAST_SYNC_AT] = timestamp }
    }
}
