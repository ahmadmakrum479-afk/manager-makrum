package com.cricketmanager.app.data.repository

import android.content.Context
import com.cricketmanager.app.data.local.AuditLogEntity
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.CricketDao
import com.cricketmanager.app.data.local.CricketDatabase
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerMatchStatEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.TournamentMemberEntity
import com.cricketmanager.app.data.local.UserEntity
import com.cricketmanager.app.data.local.UserPreferences
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.AuthSecurity
import com.cricketmanager.app.domain.BackupSerializer
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.domain.TournamentBackupBundle
import com.cricketmanager.app.sync.CloudSyncResult
import com.cricketmanager.app.sync.FirebaseSyncBridge
import com.cricketmanager.app.sync.TournamentSyncWorker
import kotlinx.coroutines.flow.Flow

data class TeamDraft(
    val name: String,
    val shortCode: String,
    val logoEmoji: String,
    val captainName: String,
    val groupName: String
)

class CricketRepository(
    private val dao: CricketDao,
    private val preferences: UserPreferences,
    private val firebaseSyncBridge: FirebaseSyncBridge,
    private val appContext: Context
) {
    val usersFlow: Flow<List<UserEntity>> = dao.observeAllUsers()
    val tournamentsFlow: Flow<List<TournamentEntity>> = dao.observeAllTournaments()
    val teamsFlow: Flow<List<TeamEntity>> = dao.observeAllTeams()
    val playersFlow: Flow<List<PlayerEntity>> = dao.observeAllPlayers()
    val matchesFlow: Flow<List<MatchEntity>> = dao.observeAllMatches()
    val ballEventsFlow: Flow<List<BallEventEntity>> = dao.observeAllBallEvents()
    val membersFlow: Flow<List<TournamentMemberEntity>> = dao.observeAllMembers()
    val auditLogsFlow: Flow<List<AuditLogEntity>> = dao.observeAllAuditLogs()
    val playerMatchStatsFlow: Flow<List<PlayerMatchStatEntity>> = dao.observeAllPlayerMatchStats()

    val activeUserIdFlow: Flow<Long> = preferences.activeUserIdFlow
    val selectedTournamentIdFlow: Flow<Long> = preferences.selectedTournamentIdFlow
    val languageCodeFlow: Flow<String> = preferences.languageCodeFlow
    val autoSyncFlow: Flow<Boolean> = preferences.autoSyncFlow
    val lastSyncAtFlow: Flow<Long> = preferences.lastSyncAtFlow

    fun isFirebaseConfigured(): Boolean = firebaseSyncBridge.isFirebaseConfigured()

    suspend fun ensureSeeded(db: CricketDatabase) {
        val seededUserId = CricketDatabase.seedDemoDataIfEmpty(db)
        if (seededUserId != null) {
            preferences.setActiveUserId(seededUserId)
        }
        val firstTournament = dao.getAllTournamentsOnce().firstOrNull()
        if (firstTournament != null) {
            preferences.setSelectedTournamentId(firstTournament.id)
        }
    }

    suspend fun registerUser(
        fullName: String,
        email: String,
        password: String,
        organization: String
    ): Result<UserEntity> {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank() || password.length < 4) {
            return Result.failure(IllegalArgumentException("Valid email and password (4+ chars) required."))
        }
        val existing = dao.getUserByEmail(cleanEmail)
        if (existing != null) {
            return Result.failure(IllegalStateException("Account already exists with this email."))
        }
        val user = UserEntity(
            fullName = fullName.trim().ifBlank { "Cricket Organizer" },
            email = cleanEmail,
            passwordHash = AuthSecurity.hashPassword(password),
            organization = organization.trim()
        )
        val id = dao.insertUser(user)
        val saved = user.copy(id = id)
        preferences.setActiveUserId(id)
        if (firebaseSyncBridge.isFirebaseConfigured()) {
            firebaseSyncBridge.signInOrRegisterFirebase(cleanEmail, password)
        }
        return Result.success(saved)
    }

    suspend fun loginUser(email: String, password: String): Result<UserEntity> {
        val cleanEmail = email.trim().lowercase()
        val user = dao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("No account found for this email."))
        if (!AuthSecurity.verifyPassword(password, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Incorrect password."))
        }
        preferences.setActiveUserId(user.id)
        if (firebaseSyncBridge.isFirebaseConfigured()) {
            firebaseSyncBridge.signInOrRegisterFirebase(cleanEmail, password)
        }
        return Result.success(user)
    }

    suspend fun continueAsGuestDemo() {
        val existing = dao.getUserByEmail("organizer@cricketmanager.app")
        if (existing != null) {
            preferences.setActiveUserId(existing.id)
        } else {
            val id = dao.insertUser(
                UserEntity(
                    fullName = "Guest Organizer",
                    email = "guest@cricketmanager.app",
                    passwordHash = AuthSecurity.hashPassword("guest123"),
                    organization = "Local Club"
                )
            )
            preferences.setActiveUserId(id)
        }
    }

    suspend fun logout() {
        preferences.setActiveUserId(0L)
    }

    suspend fun selectTournament(tournamentId: Long) {
        preferences.setSelectedTournamentId(tournamentId)
    }

    suspend fun setLanguage(code: String) {
        preferences.setLanguageCode(code)
    }

    suspend fun setAutoSync(enabled: Boolean) {
        preferences.setAutoSync(enabled)
    }

    suspend fun createTournamentWithTeams(
        ownerUser: UserEntity,
        name: String,
        logoEmoji: String,
        organizationName: String,
        pitchType: PitchType,
        scoringMode: ScoringMode,
        format: TournamentFormat,
        oversPerMatch: Int,
        groupCount: Int,
        rulesSummary: String,
        pointsWin: Int,
        pointsTie: Int,
        pointsLoss: Int,
        pointsAbandoned: Int,
        location: String,
        startDateLabel: String,
        teamDrafts: List<TeamDraft>
    ): Long {
        val tId = dao.insertTournament(
            TournamentEntity(
                ownerUserId = ownerUser.id,
                name = name.trim(),
                logoEmoji = logoEmoji.ifBlank { "🏆" },
                organizationName = organizationName.trim(),
                pitchType = pitchType,
                scoringMode = scoringMode,
                format = format,
                oversPerMatch = oversPerMatch.coerceIn(2, 50),
                maxTeams = teamDrafts.size.coerceAtLeast(2),
                groupCount = groupCount.coerceIn(1, 4),
                rulesSummary = rulesSummary.trim(),
                pointsWin = pointsWin,
                pointsTie = pointsTie,
                pointsLoss = pointsLoss,
                pointsAbandoned = pointsAbandoned,
                tournamentCode = AuthSecurity.generateCode("CM"),
                editorCode = AuthSecurity.generateCode("ED"),
                viewerCode = AuthSecurity.generateCode("VW"),
                startDateLabel = startDateLabel.ifBlank { "2026-05-01" },
                location = location.ifBlank { "Main Ground" },
                syncDirty = true
            )
        )

        dao.insertMember(
            TournamentMemberEntity(
                tournamentId = tId,
                userId = ownerUser.id,
                userName = ownerUser.fullName,
                userEmail = ownerUser.email,
                role = UserRole.OWNER,
                canEditTeams = true,
                canEditSchedule = true,
                canScore = true
            )
        )

        val insertedTeams = mutableListOf<TeamEntity>()
        teamDrafts.forEachIndexed { idx, draft ->
            val team = TeamEntity(
                tournamentId = tId,
                name = draft.name.trim(),
                shortCode = draft.shortCode.trim().uppercase().take(4).ifBlank { "T${idx + 1}" },
                logoEmoji = draft.logoEmoji.ifBlank { "🏏" },
                captainName = draft.captainName.trim(),
                groupName = draft.groupName.ifBlank { "Group A" },
                homeGround = location.ifBlank { "Main Ground" }
            )
            val teamId = dao.insertTeam(team)
            insertedTeams.add(team.copy(id = teamId))

            if (draft.captainName.isNotBlank()) {
                dao.insertPlayer(
                    PlayerEntity(
                        tournamentId = tId,
                        teamId = teamId,
                        name = draft.captainName.trim(),
                        jerseyNumber = 1,
                        role = PlayerRole.ALL_ROUNDER,
                        isCaptain = true
                    )
                )
            }
        }

        val fixtures = CricketStatsEngine.generateFixtures(
            tournamentId = tId,
            teams = insertedTeams,
            format = format,
            oversPerMatch = oversPerMatch.coerceIn(2, 50),
            scoringMode = scoringMode,
            venue = location.ifBlank { "Main Ground" },
            startDateLabel = startDateLabel.ifBlank { "2026-05-01" }
        )
        dao.insertMatches(fixtures)

        dao.insertAuditLog(
            AuditLogEntity(
                tournamentId = tId,
                actorName = ownerUser.fullName,
                actionTitle = "Created Tournament",
                details = "Created $name with ${insertedTeams.size} teams & ${fixtures.size} matches."
            )
        )

        preferences.setSelectedTournamentId(tId)
        TournamentSyncWorker.enqueueImmediateSync(appContext)
        return tId
    }

    suspend fun joinTournamentByCode(code: String, user: UserEntity): Result<Pair<TournamentEntity, UserRole>> {
        val clean = code.trim().uppercase()
        if (clean.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter a valid tournament code."))
        }
        val tournament = dao.findTournamentByAnyCode(clean)
            ?: return Result.failure(IllegalArgumentException("No tournament matches code $clean."))

        val assignedRole = when {
            clean == tournament.editorCode.uppercase() -> UserRole.EDITOR
            clean == tournament.tournamentCode.uppercase() -> UserRole.VIEWER
            else -> UserRole.VIEWER
        }

        val existingMember = dao.getMember(tournament.id, user.id)
        if (existingMember == null) {
            dao.insertMember(
                TournamentMemberEntity(
                    tournamentId = tournament.id,
                    userId = user.id,
                    userName = user.fullName,
                    userEmail = user.email,
                    role = assignedRole,
                    canEditTeams = assignedRole == UserRole.ADMIN || assignedRole == UserRole.OWNER,
                    canEditSchedule = assignedRole == UserRole.ADMIN || assignedRole == UserRole.OWNER,
                    canScore = assignedRole != UserRole.VIEWER
                )
            )
            dao.insertAuditLog(
                AuditLogEntity(
                    tournamentId = tournament.id,
                    actorName = user.fullName,
                    actionTitle = "Joined Tournament",
                    details = "${user.fullName} joined as ${assignedRole.labelEn} via code $clean."
                )
            )
        } else if (assignedRole == UserRole.EDITOR && existingMember.role == UserRole.VIEWER) {
            dao.updateMember(
                existingMember.copy(
                    role = UserRole.EDITOR,
                    canScore = true
                )
            )
        }

        preferences.setSelectedTournamentId(tournament.id)
        return Result.success(tournament to (existingMember?.role ?: assignedRole))
    }

    suspend fun addTeam(
        tournamentId: Long,
        name: String,
        shortCode: String,
        logoEmoji: String,
        captainName: String,
        groupName: String,
        homeGround: String,
        actorName: String
    ) {
        val id = dao.insertTeam(
            TeamEntity(
                tournamentId = tournamentId,
                name = name.trim(),
                shortCode = shortCode.trim().uppercase().take(4).ifBlank { "TM" },
                logoEmoji = logoEmoji.ifBlank { "🏏" },
                captainName = captainName.trim(),
                groupName = groupName.ifBlank { "Group A" },
                homeGround = homeGround.trim()
            )
        )
        if (captainName.isNotBlank()) {
            dao.insertPlayer(
                PlayerEntity(
                    tournamentId = tournamentId,
                    teamId = id,
                    name = captainName.trim(),
                    jerseyNumber = 1,
                    role = PlayerRole.ALL_ROUNDER,
                    isCaptain = true
                )
            )
        }
        logAndMarkDirty(tournamentId, actorName, "Added Team", "Added team $name ($groupName).")
    }

    suspend fun deleteTeam(team: TeamEntity, actorName: String) {
        dao.deleteTeam(team.id)
        logAndMarkDirty(team.tournamentId, actorName, "Deleted Team", "Removed team ${team.name}.")
    }

    suspend fun addPlayer(
        tournamentId: Long,
        teamId: Long,
        name: String,
        jerseyNumber: Int,
        role: PlayerRole,
        battingStyle: String,
        bowlingStyle: String,
        photoEmoji: String,
        isCaptain: Boolean,
        actorName: String
    ) {
        dao.insertPlayer(
            PlayerEntity(
                tournamentId = tournamentId,
                teamId = teamId,
                name = name.trim(),
                jerseyNumber = jerseyNumber,
                role = role,
                battingStyle = battingStyle.ifBlank { "Right-hand Bat" },
                bowlingStyle = bowlingStyle.ifBlank { "Right-arm Medium" },
                photoEmoji = photoEmoji.ifBlank { "🧑" },
                isCaptain = isCaptain
            )
        )
        logAndMarkDirty(tournamentId, actorName, "Added Player", "Registered player $name.")
    }

    suspend fun deletePlayer(player: PlayerEntity, actorName: String) {
        dao.deletePlayer(player.id)
        logAndMarkDirty(player.tournamentId, actorName, "Removed Player", "Removed ${player.name}.")
    }

    suspend fun updatePlayerStatsDirect(
        player: PlayerEntity,
        matchesPlayed: Int,
        runsScored: Int,
        ballsFaced: Int,
        fours: Int,
        sixes: Int,
        highestScore: Int,
        wicketsTaken: Int,
        runsConceded: Int,
        oversBowledText: String,
        actorName: String
    ) {
        val ballsBowled = CricketStatsEngine.parseOversToBalls(oversBowledText)
        dao.updatePlayer(
            player.copy(
                matchesPlayed = matchesPlayed.coerceAtLeast(0),
                inningsBatted = if (runsScored > 0 || ballsFaced > 0) maxOf(player.inningsBatted, 1) else player.inningsBatted,
                runsScored = runsScored.coerceAtLeast(0),
                ballsFaced = ballsFaced.coerceAtLeast(0),
                fours = fours.coerceAtLeast(0),
                sixes = sixes.coerceAtLeast(0),
                highestScore = maxOf(highestScore.coerceAtLeast(0), runsScored.coerceAtLeast(0)),
                wicketsTaken = wicketsTaken.coerceAtLeast(0),
                runsConceded = runsConceded.coerceAtLeast(0),
                ballsBowled = ballsBowled.coerceAtLeast(0)
            )
        )
        logAndMarkDirty(player.tournamentId, actorName, "Updated Player Stats", "Edited individual stats for ${player.name}.")
    }

    suspend fun createMatch(
        tournament: TournamentEntity,
        teamA: TeamEntity,
        teamB: TeamEntity,
        stage: MatchStage,
        groupName: String,
        venue: String,
        scheduledDate: String,
        scheduledTime: String,
        oversLimit: Int,
        scoringMode: ScoringMode,
        actorName: String
    ): Long {
        val currentMatches = dao.getMatchesByTournamentOnce(tournament.id)
        val nextNum = (currentMatches.maxOfOrNull { it.matchNumber } ?: 0) + 1
        val matchId = dao.insertMatch(
            MatchEntity(
                tournamentId = tournament.id,
                matchNumber = nextNum,
                stage = stage,
                groupName = groupName,
                teamAId = teamA.id,
                teamBId = teamB.id,
                teamAName = teamA.name,
                teamBName = teamB.name,
                venue = venue.ifBlank { tournament.location },
                scheduledDate = scheduledDate.ifBlank { tournament.startDateLabel },
                scheduledTime = scheduledTime.ifBlank { "15:00" },
                oversLimit = oversLimit.coerceIn(2, 50),
                scoringMode = scoringMode,
                status = MatchStatus.UPCOMING
            )
        )
        logAndMarkDirty(tournament.id, actorName, "Scheduled Match", "Match #$nextNum: ${teamA.name} vs ${teamB.name}.")
        return matchId
    }

    suspend fun generateKnockoutStage(tournament: TournamentEntity, stage: MatchStage, actorName: String): Result<Int> {
        val teams = CricketStatsEngine.sortTeamsForPointsTable(dao.getTeamsByTournamentOnce(tournament.id))
        if (teams.size < 2) {
            return Result.failure(IllegalStateException("Need at least 2 teams to generate stage."))
        }
        val existingMatches = dao.getMatchesByTournamentOnce(tournament.id)
        var nextNum = (existingMatches.maxOfOrNull { it.matchNumber } ?: 0) + 1
        val newMatches = mutableListOf<MatchEntity>()

        when (stage) {
            MatchStage.SEMI_FINAL -> {
                if (teams.size < 4) {
                    return Result.failure(IllegalStateException("Need at least 4 teams for Semi-Finals."))
                }
                newMatches.add(
                    MatchEntity(
                        tournamentId = tournament.id,
                        matchNumber = nextNum++,
                        stage = MatchStage.SEMI_FINAL,
                        groupName = "Semi-Final 1",
                        teamAId = teams[0].id,
                        teamBId = teams[3].id,
                        teamAName = teams[0].name,
                        teamBName = teams[3].name,
                        venue = tournament.location,
                        scheduledDate = tournament.startDateLabel,
                        scheduledTime = "14:00",
                        oversLimit = tournament.oversPerMatch,
                        scoringMode = tournament.scoringMode
                    )
                )
                newMatches.add(
                    MatchEntity(
                        tournamentId = tournament.id,
                        matchNumber = nextNum,
                        stage = MatchStage.SEMI_FINAL,
                        groupName = "Semi-Final 2",
                        teamAId = teams[1].id,
                        teamBId = teams[2].id,
                        teamAName = teams[1].name,
                        teamBName = teams[2].name,
                        venue = tournament.location,
                        scheduledDate = tournament.startDateLabel,
                        scheduledTime = "16:30",
                        oversLimit = tournament.oversPerMatch,
                        scoringMode = tournament.scoringMode
                    )
                )
            }
            MatchStage.FINAL -> {
                val semiWinners = existingMatches
                    .filter { it.stage == MatchStage.SEMI_FINAL && it.status == MatchStatus.COMPLETED && it.winnerTeamId > 0L }
                    .mapNotNull { m -> teams.firstOrNull { it.id == m.winnerTeamId } }
                val finalists = if (semiWinners.size >= 2) semiWinners.take(2) else teams.take(2)
                newMatches.add(
                    MatchEntity(
                        tournamentId = tournament.id,
                        matchNumber = nextNum,
                        stage = MatchStage.FINAL,
                        groupName = "Grand Final",
                        teamAId = finalists[0].id,
                        teamBId = finalists[1].id,
                        teamAName = finalists[0].name,
                        teamBName = finalists[1].name,
                        venue = tournament.location,
                        scheduledDate = tournament.startDateLabel,
                        scheduledTime = "16:00",
                        oversLimit = tournament.oversPerMatch,
                        scoringMode = tournament.scoringMode
                    )
                )
            }
            else -> Unit
        }

        if (newMatches.isEmpty()) return Result.failure(IllegalStateException("No matches generated."))
        dao.insertMatches(newMatches)
        logAndMarkDirty(tournament.id, actorName, "Generated ${stage.labelEn}", "Added ${newMatches.size} ${stage.labelEn} fixture(s).")
        return Result.success(newMatches.size)
    }

    suspend fun updateMatchPlayersAndInnings(
        matchId: Long,
        currentInnings: Int,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        status: MatchStatus = MatchStatus.LIVE
    ) {
        val m = dao.getMatchById(matchId) ?: return
        dao.updateMatch(
            m.copy(
                currentInnings = currentInnings,
                activeStrikerId = strikerId,
                activeNonStrikerId = nonStrikerId,
                activeBowlerId = bowlerId,
                status = status,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun swapStrike(matchId: Long) {
        val m = dao.getMatchById(matchId) ?: return
        dao.updateMatch(
            m.copy(
                activeStrikerId = m.activeNonStrikerId,
                activeNonStrikerId = m.activeStrikerId,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun recordBall(
        matchId: Long,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        runsOffBat: Int,
        extraRuns: Int,
        extraType: ExtraType,
        isWicket: Boolean,
        wicketType: WicketType,
        dismissedPlayerId: Long
    ) {
        dao.recordBallAndApplyStats(
            matchId = matchId,
            strikerId = strikerId,
            nonStrikerId = nonStrikerId,
            bowlerId = bowlerId,
            runsOffBat = runsOffBat,
            extraRuns = extraRuns,
            extraType = extraType,
            isWicket = isWicket,
            wicketType = wicketType,
            dismissedPlayerId = dismissedPlayerId
        )
    }

    suspend fun undoLastBall(matchId: Long) {
        dao.undoLastBallInMatch(matchId)
    }

    suspend fun editBallEvent(
        ballId: Long,
        newRunsOffBat: Int,
        newExtraRuns: Int,
        newExtraType: ExtraType,
        newIsWicket: Boolean,
        newWicketType: WicketType,
        actorName: String
    ) {
        val old = dao.getBallById(ballId) ?: return
        val match = dao.getMatchById(old.matchId) ?: return
        val newLabel = CricketStatsEngine.formatBallChip(newRunsOffBat, newExtraRuns, newExtraType, newIsWicket)
        dao.updateBallEvent(
            old.copy(
                runsOffBat = newRunsOffBat,
                extraRuns = newExtraRuns,
                extraType = newExtraType,
                isWicket = newIsWicket,
                wicketType = if (newIsWicket) newWicketType else WicketType.NONE,
                isBoundaryFour = newRunsOffBat == 4,
                isBoundarySix = newRunsOffBat == 6,
                summaryLabel = newLabel
            )
        )
        // Recompute innings totals accurately from all ball events in match
        val allBalls = dao.getBallEventsForMatchOnce(match.id)
        val i1 = allBalls.filter { it.innings == 1 }
        val i2 = allBalls.filter { it.innings == 2 }
        dao.updateMatch(
            match.copy(
                teamARuns = i1.sumOf { it.runsOffBat + it.extraRuns },
                teamAWickets = i1.count { it.isWicket },
                teamABalls = i1.count { CricketStatsEngine.isLegalDelivery(it.extraType) },
                teamAExtras = i1.sumOf { it.extraRuns },
                teamBRuns = i2.sumOf { it.runsOffBat + it.extraRuns },
                teamBWickets = i2.count { it.isWicket },
                teamBBalls = i2.count { CricketStatsEngine.isLegalDelivery(it.extraType) },
                teamBExtras = i2.sumOf { it.extraRuns },
                updatedAt = System.currentTimeMillis()
            )
        )
        logAndMarkDirty(
            match.tournamentId,
            actorName,
            "Edited Ball #${old.sequenceNumber}",
            "Updated ball in Match #${match.matchNumber} to $newLabel."
        )
    }

    suspend fun finalizeMatch(
        matchId: Long,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        isAbandoned: Boolean,
        actorName: String
    ) {
        val m = dao.getMatchById(matchId) ?: return
        dao.finalizeMatch(matchId, playerOfMatchId, playerOfMatchName, isAbandoned)
        logAndMarkDirty(
            m.tournamentId,
            actorName,
            "Finalized Match #${m.matchNumber}",
            "Completed ${m.teamAName} vs ${m.teamBName}. POM: ${playerOfMatchName.ifBlank { "N/A" }}."
        )
    }

    suspend fun submitManualScore(
        matchId: Long,
        teamARuns: Int,
        teamAWickets: Int,
        teamAOversText: String,
        teamAExtras: Int,
        teamBRuns: Int,
        teamBWickets: Int,
        teamBOversText: String,
        teamBExtras: Int,
        playerStats: List<PlayerMatchStatEntity>,
        playerOfMatchId: Long,
        playerOfMatchName: String,
        customResultText: String,
        actorName: String
    ) {
        val m = dao.getMatchById(matchId) ?: return
        dao.submitManualMatchScore(
            matchId = matchId,
            teamARuns = teamARuns,
            teamAWickets = teamAWickets,
            teamABalls = CricketStatsEngine.parseOversToBalls(teamAOversText),
            teamAExtras = teamAExtras,
            teamBRuns = teamBRuns,
            teamBWickets = teamBWickets,
            teamBBalls = CricketStatsEngine.parseOversToBalls(teamBOversText),
            teamBExtras = teamBExtras,
            playerStats = playerStats,
            playerOfMatchId = playerOfMatchId,
            playerOfMatchName = playerOfMatchName,
            customResultText = customResultText
        )
        logAndMarkDirty(
            m.tournamentId,
            actorName,
            "Manual Score Saved",
            "Saved Match #${m.matchNumber} (${m.teamAName} $teamARuns/$teamAWickets vs ${m.teamBName} $teamBRuns/$teamBWickets)."
        )
    }

    suspend fun updateMemberPermissions(
        member: TournamentMemberEntity,
        newRole: UserRole,
        canEditTeams: Boolean,
        canEditSchedule: Boolean,
        canScore: Boolean,
        actorName: String
    ) {
        dao.updateMember(
            member.copy(
                role = newRole,
                canEditTeams = canEditTeams,
                canEditSchedule = canEditSchedule,
                canScore = canScore
            )
        )
        logAndMarkDirty(
            member.tournamentId,
            actorName,
            "Updated Role",
            "Updated ${member.userName} to ${newRole.labelEn}."
        )
    }

    suspend fun removeMember(member: TournamentMemberEntity, actorName: String) {
        dao.deleteMember(member.id)
        logAndMarkDirty(
            member.tournamentId,
            actorName,
            "Revoked Access",
            "Removed ${member.userName} from tournament."
        )
    }

    suspend fun addMemberManually(
        tournamentId: Long,
        name: String,
        email: String,
        role: UserRole,
        actorName: String
    ) {
        val cleanEmail = email.trim().lowercase()
        val existingUser = dao.getUserByEmail(cleanEmail)
        val userId = existingUser?.id ?: dao.insertUser(
            UserEntity(
                fullName = name.trim(),
                email = cleanEmail,
                passwordHash = AuthSecurity.hashPassword("123456"),
                organization = "Invited Member"
            )
        )
        dao.insertMember(
            TournamentMemberEntity(
                tournamentId = tournamentId,
                userId = userId,
                userName = name.trim(),
                userEmail = cleanEmail,
                role = role,
                canEditTeams = role == UserRole.OWNER || role == UserRole.ADMIN,
                canEditSchedule = role == UserRole.OWNER || role == UserRole.ADMIN,
                canScore = role != UserRole.VIEWER
            )
        )
        logAndMarkDirty(tournamentId, actorName, "Added Member", "Added $name as ${role.labelEn}.")
    }

    suspend fun regenerateCodes(tournament: TournamentEntity, actorName: String) {
        dao.updateTournament(
            tournament.copy(
                editorCode = AuthSecurity.generateCode("ED"),
                viewerCode = AuthSecurity.generateCode("VW"),
                syncDirty = true,
                updatedAt = System.currentTimeMillis()
            )
        )
        logAndMarkDirty(tournament.id, actorName, "Regenerated Access Codes", "Rotated Editor & Viewer join codes.")
    }

    suspend fun exportTournamentBackupJson(tournamentId: Long): Result<String> {
        val t = dao.getTournamentById(tournamentId)
            ?: return Result.failure(IllegalStateException("Select a tournament first."))
        val bundle = TournamentBackupBundle(
            tournament = t,
            teams = dao.getTeamsByTournamentOnce(tournamentId),
            players = dao.getPlayersByTournamentOnce(tournamentId),
            matches = dao.getMatchesByTournamentOnce(tournamentId),
            balls = dao.getMatchesByTournamentOnce(tournamentId).flatMap { dao.getBallEventsForMatchOnce(it.id) },
            members = dao.getMembersByTournamentOnce(tournamentId),
            logs = dao.getAuditLogsOnce(tournamentId)
        )
        return Result.success(BackupSerializer.exportTournamentJson(bundle))
    }

    suspend fun importTournamentBackupJson(rawJson: String, currentUserId: Long): Result<Long> {
        return runCatching {
            val bundle = BackupSerializer.parseTournamentJson(rawJson, currentUserId)
            val newId = dao.replaceTournamentBundle(
                tournament = bundle.tournament,
                teams = bundle.teams,
                players = bundle.players,
                matches = bundle.matches,
                balls = bundle.balls,
                members = bundle.members,
                logs = bundle.logs
            )
            preferences.setSelectedTournamentId(newId)
            TournamentSyncWorker.enqueueImmediateSync(appContext)
            newId
        }
    }

    suspend fun triggerSyncNow(): CloudSyncResult {
        TournamentSyncWorker.enqueueImmediateSync(appContext)
        val dirty = dao.getAllTournamentsOnce().filter { it.syncDirty }
        val result = firebaseSyncBridge.pushDirtyTournaments(dirty, "active-user")
        if (result is CloudSyncResult.Synced) {
            dirty.forEach { dao.updateTournament(it.copy(syncDirty = false)) }
            preferences.setLastSyncAt(System.currentTimeMillis())
        }
        return result
    }

    private suspend fun logAndMarkDirty(
        tournamentId: Long,
        actorName: String,
        title: String,
        details: String
    ) {
        dao.insertAuditLog(
            AuditLogEntity(
                tournamentId = tournamentId,
                actorName = actorName,
                actionTitle = title,
                details = details
            )
        )
        dao.getTournamentById(tournamentId)?.let { t ->
            dao.updateTournament(t.copy(syncDirty = true, updatedAt = System.currentTimeMillis()))
        }
        TournamentSyncWorker.enqueueImmediateSync(appContext)
    }
}
