package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.AppLanguage
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.ui.theme.PitchEmeraldDark
import com.cricketmanager.app.viewmodel.CricketUiState
import java.util.Locale

@Composable
fun StatisticsScreen(
    tournamentId: Long,
    uiState: CricketUiState,
    onBack: () -> Unit
) {
    val strings = LocalAppStrings.current
    val isBn = strings.language == AppLanguage.BN
    val tournament = uiState.tournaments.firstOrNull { it.id == tournamentId } ?: uiState.selectedTournament
    val tId = tournament?.id ?: tournamentId
    val players = uiState.allPlayers.filter { it.tournamentId == tId }
    val teams = uiState.allTeams.filter { it.tournamentId == tId }
    val tMatches = uiState.allMatches.filter { it.tournamentId == tId }
    val tMatchStats = uiState.allPlayerMatchStats.filter { it.tournamentId == tId }

    val fantasyByPlayerId = remember(players, tMatchStats, tMatches) {
        players.associate { p ->
            p.id to CricketStatsEngine.calculateTournamentFantasyBreakdown(p, tMatchStats, tMatches)
        }
    }

    val tabs = if (isBn) {
        listOf("ফ্যান্টাসি MVP", "সর্বোচ্চ রান", "সর্বোচ্চ উইকেট", "স্ট্রাইক রেট", "সেরা বোলিং")
    } else {
        listOf("Fantasy MVP", "Top Runs", "Top Wickets", "Strike Rate", "Best Bowling")
    }
    var selectedTab by remember { mutableIntStateOf(0) }

    val ranked = when (selectedTab) {
        0 -> players.sortedByDescending { fantasyByPlayerId[it.id]?.totalPts ?: 0 }
        1 -> players.sortedByDescending { it.runsScored }
        2 -> players.sortedByDescending { it.wicketsTaken }
        3 -> players.filter { it.ballsFaced >= 6 }.ifEmpty { players }
            .sortedByDescending { CricketStatsEngine.calculateStrikeRate(it.runsScored, it.ballsFaced) }
        else -> players.sortedWith(
            compareByDescending<com.cricketmanager.app.data.local.PlayerEntity> { it.bestBowlingWickets }
                .thenBy { it.bestBowlingRuns }
                .thenByDescending { it.wicketsTaken }
        )
    }

    val mvpPlayer = players.maxByOrNull { fantasyByPlayerId[it.id]?.totalPts ?: 0 }
    val mvpBreakdown = mvpPlayer?.let { fantasyByPlayerId[it.id] }
    val topRunScorer = players.maxByOrNull { it.runsScored }
    val topWicketTaker = players.maxByOrNull { it.wicketsTaken }

    Scaffold(
        topBar = { ScreenTopBar(title = strings.statistics, subtitle = tournament?.name, onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (mvpPlayer != null && mvpBreakdown != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = PitchEmeraldDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (isBn) "🏆 ম্যান অফ দ্যা টুর্নামেন্ট লিডার (ফ্যান্টাসি পয়েন্ট)" else "🏆 Man of the Tournament Leader (Fantasy MVP)",
                                color = Color(0xFFFDE68A),
                                style = MaterialTheme.typography.labelMedium
                            )
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(mvpPlayer.name, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("${mvpBreakdown.totalPts} pts", color = Color(0xFFFDE68A), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            }
                            Text(
                                text = "Bat: ${mvpBreakdown.battingPts} · Bowl: ${mvpBreakdown.bowlingPts} · Bonus/POM: ${mvpBreakdown.bonusPts} · (${mvpPlayer.runsScored}R, ${mvpPlayer.wicketsTaken}W, ${mvpPlayer.playerOfMatchCount} POM)",
                                color = Color(0xFFD1FAE5),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            if (topRunScorer != null && topWicketTaker != null) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(if (isBn) "🏏 সর্বোচ্চ রান" else "🏏 Top Run Scorer", style = MaterialTheme.typography.labelSmall, color = PitchEmerald)
                                Text(topRunScorer.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("${topRunScorer.runsScored} Runs (HS ${topRunScorer.highestScore})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(if (isBn) "⚾ সর্বোচ্চ উইকেট" else "⚾ Top Wicket Taker", style = MaterialTheme.typography.labelSmall, color = PitchEmerald)
                                Text(topWicketTaker.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("${topWicketTaker.wicketsTaken} Wkts (Best ${topWicketTaker.bestBowlingWickets}/${topWicketTaker.bestBowlingRuns})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tabs.forEachIndexed { idx, label ->
                        item {
                            FilterChip(
                                selected = selectedTab == idx,
                                onClick = { selectedTab = idx },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            itemsIndexed(ranked, key = { _, p -> p.id }) { index, player ->
                val teamName = teams.firstOrNull { it.id == player.teamId }?.shortCode ?: ""
                val sr = CricketStatsEngine.calculateStrikeRate(player.runsScored, player.ballsFaced)
                val eco = CricketStatsEngine.calculateEconomyRate(player.runsConceded, player.ballsBowled)
                val bd = fantasyByPlayerId[player.id]
                val metric = when (selectedTab) {
                    0 -> "${bd?.totalPts ?: 0} pts"
                    1 -> "${player.runsScored} R (${player.ballsFaced}B) · HS ${player.highestScore}"
                    2 -> "${player.wicketsTaken} W · Econ ${String.format(Locale.US, "%.2f", eco)}"
                    3 -> String.format(Locale.US, "SR %.1f (%dR/%dB)", sr, player.runsScored, player.ballsFaced)
                    else -> if (player.bestBowlingWickets > 0) "${player.bestBowlingWickets}/${player.bestBowlingRuns}" else "0/0"
                }
                val subLine = if (selectedTab == 0 && bd != null) {
                    "Bat: ${bd.battingPts} · Bowl: ${bd.bowlingPts} · Bonus: ${bd.bonusPts} · POM: ${player.playerOfMatchCount}"
                } else {
                    "${player.role.labelEn} · 4s: ${player.fours} · 6s: ${player.sixes} · Fantasy: ${bd?.totalPts ?: 0}p"
                }

                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("#${index + 1} ${player.name} ($teamName)", fontWeight = FontWeight.Bold)
                            Text(
                                text = subLine,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(metric, fontWeight = FontWeight.Bold, color = PitchEmerald)
                    }
                }
            }

            if (selectedTab == 0) {
                item {
                    Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (isBn) "ফ্যান্টাসি পয়েন্ট হিসাবের নিয়ম (অটো গণনা)" else "Fantasy Points System (Auto Calculated)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isBn) {
                                    "• ব্যাটিং: প্রতি রান +1, চার +1, ছক্কা +2, ৩০+ (+10), ৫০+ (+20), ১০০+ (+40), স্ট্রাইক রেট বোনাস (+3 থেকে +10)"
                                } else {
                                    "• Batting: Run +1, Four +1, Six +2, 30+/50+/100+ (+10/+20/+40), SR Bonus (+3 to +10)"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (isBn) {
                                    "• বোলিং: প্রতি উইকেট +25, ৩ উইকেট (+12), ৫ উইকেট (+25), ইকোনমি বোনাস (+5 থেকে +10)"
                                } else {
                                    "• Bowling: Wicket +25, 3W/5W Haul (+12/+25), Economy Bonus (+5 to +10)"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (isBn) {
                                    "• অতিরিক্ত: জয়ী দলের অবদান +5, নট আউট (১০+ রান) +3, ম্যান অফ দ্যা ম্যাচ +20"
                                } else {
                                    "• Bonus: Winning Team Impact +5, Not Out (10+ runs) +3, Man of the Match +20"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
