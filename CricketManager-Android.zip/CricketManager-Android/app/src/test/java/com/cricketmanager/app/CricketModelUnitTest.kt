package com.cricketmanager.app

import com.cricketmanager.app.data.local.Converters
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchStage
import com.cricketmanager.app.data.local.PitchType
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.ScoringMode
import com.cricketmanager.app.data.local.TournamentFormat
import com.cricketmanager.app.data.local.UserRole
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.AuthSecurity
import com.cricketmanager.app.domain.CricketStatsEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CricketModelUnitTest {

    @Test
    fun netRunRate_isCalculatedAccurately() {
        // Scored 120 in 10 overs (12.0 RPO), conceded 100 in 10 overs (10.0 RPO) -> +2.000
        val nrr = CricketStatsEngine.calculateNetRunRate(
            runsFor = 120,
            ballsFaced = 60,
            runsAgainst = 100,
            ballsBowled = 60
        )
        assertEquals(2.0, nrr, 0.001)
        assertEquals("+2.000", CricketStatsEngine.formatNrr(nrr))
    }

    @Test
    fun oversFormattingAndParsing_roundTripsCorrectly() {
        assertEquals("0.0", CricketStatsEngine.formatOvers(0))
        assertEquals("3.4", CricketStatsEngine.formatOvers(22))
        assertEquals(22, CricketStatsEngine.parseOversToBalls("3.4"))
        assertEquals(48, CricketStatsEngine.parseOversToBalls("8"))
    }

    @Test
    fun ballChipFormatting_handlesExtrasAndWickets() {
        assertEquals("•", CricketStatsEngine.formatBallChip(0, 0, ExtraType.NONE, false))
        assertEquals("4", CricketStatsEngine.formatBallChip(4, 0, ExtraType.NONE, false))
        assertEquals("Wd", CricketStatsEngine.formatBallChip(0, 1, ExtraType.WIDE, false))
        assertEquals("W", CricketStatsEngine.formatBallChip(0, 0, ExtraType.NONE, true))
        assertTrue(CricketStatsEngine.isLegalDelivery(ExtraType.BYE))
        assertFalse(CricketStatsEngine.isLegalDelivery(ExtraType.WIDE))
    }

    @Test
    fun passwordHash_andConverters_workDeterministically() {
        val hash = AuthSecurity.hashPassword("secret123")
        assertTrue(AuthSecurity.verifyPassword("secret123", hash))
        assertFalse(AuthSecurity.verifyPassword("wrong", hash))

        val conv = Converters()
        assertEquals(PitchType.SHORT_PITCH, conv.toPitchType(conv.fromPitchType(PitchType.SHORT_PITCH)))
        assertEquals(ScoringMode.MANUAL, conv.toScoringMode(conv.fromScoringMode(ScoringMode.MANUAL)))
        assertEquals(TournamentFormat.GROUP_KNOCKOUT, conv.toTournamentFormat(conv.fromTournamentFormat(TournamentFormat.GROUP_KNOCKOUT)))
        assertEquals(MatchStage.SEMI_FINAL, conv.toMatchStage(conv.fromMatchStage(MatchStage.SEMI_FINAL)))
        assertEquals(PlayerRole.WICKET_KEEPER, conv.toPlayerRole(conv.fromPlayerRole(PlayerRole.WICKET_KEEPER)))
        assertEquals(WicketType.LBW, conv.toWicketType(conv.fromWicketType(WicketType.LBW)))
        assertEquals(UserRole.EDITOR, conv.toUserRole(conv.fromUserRole(UserRole.EDITOR)))
    }
}
